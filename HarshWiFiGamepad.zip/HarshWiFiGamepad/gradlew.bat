@echo off
setlocal

set APP_HOME=%~dp0
set CLASSPATH=%APP_HOME%gradle\wrapper\gradle-wrapper.jar

if not exist "%CLASSPATH%" (
  echo gradle-wrapper.jar not found.
  echo Open this project in Android Studio to auto-generate it, or run:
  echo   gradle wrapper --gradle-version 8.7
  echo from a machine with Gradle installed, then re-run gradlew.bat.
  exit /b 1
)

java -classpath "%CLASSPATH%" org.gradle.wrapper.GradleWrapperMain %*
