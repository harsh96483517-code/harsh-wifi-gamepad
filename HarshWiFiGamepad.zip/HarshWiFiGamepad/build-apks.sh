#!/bin/sh
# One-command build: generates gradle-wrapper.jar if missing, then builds both debug APKs.
# Requires: internet, JDK 17+, Android SDK (ANDROID_HOME set) and either `gradle` or Android Studio's Gradle.
set -e
cd "$(dirname "$0")"
if [ ! -f gradle/wrapper/gradle-wrapper.jar ]; then
  echo ">> Generating Gradle 8.7 wrapper..."
  gradle wrapper --gradle-version 8.7 --distribution-type bin
fi
./gradlew :controller:assembleDebug :tvreceiver:assembleDebug
mkdir -p dist
cp controller/build/outputs/apk/debug/controller-debug.apk dist/
cp tvreceiver/build/outputs/apk/debug/tvreceiver-debug.apk dist/
echo ">> Done: dist/controller-debug.apk and dist/tvreceiver-debug.apk"
