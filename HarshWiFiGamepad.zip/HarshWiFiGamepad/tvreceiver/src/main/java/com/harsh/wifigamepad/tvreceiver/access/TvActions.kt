package com.harsh.wifigamepad.tvreceiver.access

import android.content.Context
import android.media.AudioManager
import android.view.KeyEvent
import com.harsh.wifigamepad.protocol.ButtonCode

/** Volume + media keys. Needs no special permission and works even when the app is in the background. */
object TvActions {
    private var audio: AudioManager? = null

    fun init(context: Context) {
        audio = context.applicationContext.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
    }

    fun handle(code: ButtonCode) {
        val a = audio ?: return
        try {
            when (code) {
                ButtonCode.VOL_UP -> a.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
                ButtonCode.VOL_DOWN -> a.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
                ButtonCode.MUTE -> a.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_TOGGLE_MUTE, AudioManager.FLAG_SHOW_UI)
                ButtonCode.PLAY_PAUSE -> media(a, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE)
                ButtonCode.NEXT -> media(a, KeyEvent.KEYCODE_MEDIA_NEXT)
                ButtonCode.PREV -> media(a, KeyEvent.KEYCODE_MEDIA_PREVIOUS)
                ButtonCode.REWIND -> media(a, KeyEvent.KEYCODE_MEDIA_REWIND)
                ButtonCode.FORWARD -> media(a, KeyEvent.KEYCODE_MEDIA_FAST_FORWARD)
                else -> {}
            }
        } catch (_: Exception) {
        }
    }

    private fun media(a: AudioManager, key: Int) {
        a.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, key))
        a.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, key))
    }
}
