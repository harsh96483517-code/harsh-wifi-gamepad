package com.harsh.wifigamepad.tvreceiver.network

import java.net.Inet4Address
import java.net.NetworkInterface

/** Best-effort local IPv4 lookup that works for both Wi-Fi and hotspot-mode TV boxes. */
object LocalIpAddress {
    fun get(): String? = try {
        NetworkInterface.getNetworkInterfaces().asSequence()
            .filter { it.isUp && !it.isLoopback }
            .flatMap { it.inetAddresses.asSequence() }
            .filterIsInstance<Inet4Address>()
            .map { it.hostAddress }
            .firstOrNull { it != null && !it.startsWith("127.") }
    } catch (_: Exception) {
        null
    }
}
