package com.harsh.wifigamepad.tvreceiver

import android.app.Application
import com.harsh.wifigamepad.tvreceiver.access.TvActions

class HarshReceiverApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        TvActions.init(this)
    }
}
