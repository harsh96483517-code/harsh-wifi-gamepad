package com.harsh.wifigamepad.tvreceiver.network

import com.harsh.wifigamepad.protocol.ByeFrame
import com.harsh.wifigamepad.protocol.DiscoveryRequest
import com.harsh.wifigamepad.protocol.DiscoveryResponse
import com.harsh.wifigamepad.protocol.HelloFrame
import com.harsh.wifigamepad.protocol.InputFrame
import com.harsh.wifigamepad.protocol.PingFrame
import com.harsh.wifigamepad.protocol.PongFrame
import com.harsh.wifigamepad.protocol.ProtocolConstants
import com.harsh.wifigamepad.protocol.RejectFrame
import com.harsh.wifigamepad.protocol.WelcomeFrame
import com.harsh.wifigamepad.protocol.GamepadEvent
import com.harsh.wifigamepad.tvreceiver.access.HarshAccessibilityService
import com.harsh.wifigamepad.tvreceiver.access.TvActions
import com.harsh.wifigamepad.tvreceiver.api.ControllerInputBus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetSocketAddress
import java.net.SocketException
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

data class ConnectedController(
    val sessionToken: String,
    val slot: Int,
    val controllerId: String,
    val name: String,
    val address: InetSocketAddress,
    var lastSeenMillis: Long
)

data class ServerStatus(
    val running: Boolean = false,
    val port: Int = ProtocolConstants.DEFAULT_GAME_PORT,
    val controllers: List<ConnectedController> = emptyList(),
    val rootGamepadActive: Boolean = false
)

/**
 * Local-network-only receiver server. Two responsibilities on two sockets:
 *  - a UDP socket on [ProtocolConstants.DISCOVERY_PORT] that answers
 *    broadcast "who's out there" requests so phones can auto-discover this TV
 *  - a UDP socket on [gamePort] that handles pairing (HELLO/WELCOME/REJECT),
 *    liveness (PING/PONG) and gameplay INPUT frames
 *
 * Never talks to anything off the local network. Rejects any HELLO whose PIN
 * does not match the currently displayed pairing PIN.
 */
class GamepadServer(
    private val tvName: String,
    private val gamePort: Int = ProtocolConstants.DEFAULT_GAME_PORT
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var discoverySocket: DatagramSocket? = null
    private var gameSocket: DatagramSocket? = null
    private var discoveryJob: Job? = null
    private var gameJob: Job? = null
    private var staleCheckJob: Job? = null

    private val controllersByToken = ConcurrentHashMap<String, ConnectedController>()
    private val usedSlots = ConcurrentHashMap<Int, Boolean>()

    /**
     * Best-effort root-only virtual gamepad (see RootInputInjector for why this
     * is the only way to get full, analog-capable input into apps like PPSSPP
     * that we can't modify). Silently inert on non-rooted devices.
     */
    private val rootInjector = RootInputInjector()

    /** Rotates on every server start; shown as the pairing PIN and embedded in the QR payload. */
    var currentPin: String = generatePin()
        private set

    private val _status = MutableStateFlow(ServerStatus())
    val status: StateFlow<ServerStatus> = _status.asStateFlow()

    private val _events = MutableStateFlow<String?>(null)
    /** Last human-readable event, e.g. "Connected: HARSH PHONE", for a toast/log UI. */
    val lastEvent: StateFlow<String?> = _events.asStateFlow()

    fun start() {
        stop() // ensure clean state if called twice
        currentPin = generatePin()

        discoverySocket = DatagramSocket(null).apply {
            reuseAddress = true
            bind(InetSocketAddress(ProtocolConstants.DISCOVERY_PORT))
        }
        gameSocket = DatagramSocket(null).apply {
            reuseAddress = true
            bind(InetSocketAddress(gamePort))
        }

        _status.value = ServerStatus(running = true, port = gamePort, controllers = emptyList())
        val rootActive = rootInjector.start()
        _status.value = _status.value.copy(rootGamepadActive = rootActive)

        discoveryJob = scope.launch { runDiscoveryLoop() }
        gameJob = scope.launch { runGameLoop() }
        staleCheckJob = scope.launch { pruneStaleControllers() }
    }

    private suspend fun runDiscoveryLoop() {
        val ds = discoverySocket ?: return
        val buf = ByteArray(512)
        while (scope.isActive) {
            try {
                val packet = DatagramPacket(buf, buf.size)
                ds.receive(packet)
                val text = String(packet.data, 0, packet.length)
                if (DiscoveryRequest.decode(text) != null) {
                    val resp = DiscoveryResponse(tvName, gamePort).encode().toByteArray()
                    ds.send(DatagramPacket(resp, resp.size, packet.address, packet.port))
                }
            } catch (e: SocketException) {
                break // socket closed -> stop() was called
            } catch (_: Exception) {
                // ignore malformed packets, keep serving
            }
        }
    }

    private suspend fun runGameLoop() {
        val gs = gameSocket ?: return
        val buf = ByteArray(1024)
        while (scope.isActive) {
            try {
                val packet = DatagramPacket(buf, buf.size)
                gs.receive(packet)
                val text = String(packet.data, 0, packet.length)
                val from = InetSocketAddress(packet.address, packet.port)
                handleIncoming(text, from)
            } catch (e: SocketException) {
                break
            } catch (_: Exception) {
                // ignore malformed packets
            }
        }
    }

    private fun handleIncoming(text: String, from: InetSocketAddress) {
        HelloFrame.decode(text)?.let { hello ->
            handleHello(hello, from)
            return
        }
        InputFrame.decode(text)?.let { frame ->
            val controller = controllersByToken[frame.sessionToken] ?: return
            controller.lastSeenMillis = System.currentTimeMillis()
            ControllerInputBus.dispatch(controller.slot, frame.event)
            rootInjector.onEvent(frame.event)
            (frame.event as? GamepadEvent.ButtonDown)?.let { TvActions.handle(it.code) }
            if (!rootInjector.isActive) HarshAccessibilityService.instance?.handle(frame.event)
            return
        }
        PingFrame.decode(text)?.let { ping ->
            val controller = controllersByToken.values.firstOrNull { it.address == from } ?: return
            controller.lastSeenMillis = System.currentTimeMillis()
            sendRaw(PongFrame(ping.clientTimeMillis, System.currentTimeMillis()).encode(), from)
            return
        }
        ByeFrame.decode(text)?.let { bye ->
            controllersByToken.remove(bye.sessionToken)?.let { c ->
                usedSlots.remove(c.slot)
                _events.value = "Disconnected: ${c.name}"
                publishControllers()
            }
            return
        }
    }

    private fun handleHello(hello: HelloFrame, from: InetSocketAddress) {
        if (hello.pin != currentPin) {
            sendRaw(RejectFrame("Incorrect PIN").encode(), from)
            return
        }
        // Reconnect case: same controllerId already has a session -> reuse its slot.
        val existing = controllersByToken.values.firstOrNull { it.controllerId == hello.controllerId }
        val slot = existing?.slot ?: nextFreeSlot()
        if (slot == null) {
            sendRaw(RejectFrame("TV is full (max ${ProtocolConstants.MAX_CONTROLLERS} controllers)").encode(), from)
            return
        }
        existing?.let { controllersByToken.remove(it.sessionToken) }

        val token = UUID.randomUUID().toString()
        val controller = ConnectedController(
            sessionToken = token,
            slot = slot,
            controllerId = hello.controllerId,
            name = hello.controllerName,
            address = from,
            lastSeenMillis = System.currentTimeMillis()
        )
        controllersByToken[token] = controller
        usedSlots[slot] = true
        sendRaw(WelcomeFrame(token, slot).encode(), from)
        _events.value = "Connected: ${hello.controllerName}"
        publishControllers()
    }

    private fun nextFreeSlot(): Int? {
        for (i in 0 until ProtocolConstants.MAX_CONTROLLERS) {
            if (usedSlots[i] != true) return i
        }
        return null
    }

    private suspend fun pruneStaleControllers() {
        while (scope.isActive) {
            kotlinx.coroutines.delay(3000)
            val now = System.currentTimeMillis()
            val stale = controllersByToken.values.filter { now - it.lastSeenMillis > 8000 }
            if (stale.isNotEmpty()) {
                stale.forEach {
                    controllersByToken.remove(it.sessionToken)
                    usedSlots.remove(it.slot)
                    _events.value = "Timed out: ${it.name}"
                }
                publishControllers()
            }
        }
    }

    private fun publishControllers() {
        _status.value = _status.value.copy(controllers = controllersByToken.values.toList())
    }

    private fun sendRaw(text: String, to: InetSocketAddress) {
        try {
            val gs = gameSocket ?: return
            val bytes = text.toByteArray()
            gs.send(DatagramPacket(bytes, bytes.size, to.address, to.port))
        } catch (_: Exception) {
            // best-effort
        }
    }

    /** Disconnects a specific controller (used by the "disconnect device" UI action). */
    fun disconnect(sessionToken: String) {
        controllersByToken.remove(sessionToken)?.let {
            usedSlots.remove(it.slot)
            publishControllers()
        }
    }

    /** Stops both sockets and cancels all coroutines. Safe to call multiple times. */
    fun stop() {
        discoveryJob?.cancel(); gameJob?.cancel(); staleCheckJob?.cancel()
        try { discoverySocket?.close() } catch (_: Exception) {}
        try { gameSocket?.close() } catch (_: Exception) {}
        rootInjector.stop()
        discoverySocket = null
        gameSocket = null
        controllersByToken.clear()
        usedSlots.clear()
        _status.value = ServerStatus(running = false, port = gamePort, controllers = emptyList())
    }

    private fun generatePin(): String = (1000 + (Math.random() * 9000).toInt()).toString()
}
