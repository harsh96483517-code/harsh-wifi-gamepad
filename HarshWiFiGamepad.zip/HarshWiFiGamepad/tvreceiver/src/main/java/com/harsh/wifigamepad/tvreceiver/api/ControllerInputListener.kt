package com.harsh.wifigamepad.tvreceiver.api

import com.harsh.wifigamepad.protocol.ButtonCode
import com.harsh.wifigamepad.protocol.GamepadEvent

/**
 * IMPORTANT / HONEST LIMITATION
 * -----------------------------
 * Wi-Fi alone lets this receiver app RECEIVE controller events reliably. It
 * does NOT let it inject arbitrary key presses into every other app or game
 * on the TV. Android sandboxes apps from each other; general-purpose input
 * injection into arbitrary third-party apps requires either:
 *   - the target game integrating directly with this receiver's API (this
 *     file), which is the most reliable and recommended path, or
 *   - the user granting this app an AccessibilityService with the
 *     "can perform gestures" / key-injection capability, which only works
 *     for apps and UI elements that expose accessible nodes or accept
 *     synthesized key events, and is still not guaranteed to work with
 *     games that render their own input (most game engines do), or
 *   - the receiver being used as a local input source for its OWN app
 *     (e.g. a game built on top of this receiver, or a game embedding this
 *     module) - in that case events are simply Kotlin callbacks.
 *
 * This receiver implements all three layers, in this priority order:
 *   1. Direct API (this interface) - always available, zero permissions.
 *   2. In-app translation to Android KeyEvents for apps built on top of
 *      this receiver (see MainActivity's onKeyDown/onKeyUp forwarding).
 *   3. Optional AccessibilityService bridge (stubbed - disabled by default,
 *      requires the user to explicitly enable it in Android Settings) for
 *      best-effort control of some other apps. This is NOT implemented as
 *      an unconditional guarantee because Android does not allow it.
 */
interface ControllerInputListener {
    /** Called for every raw button/joystick event, tagged with which player slot sent it. */
    fun onGamepadEvent(slot: Int, event: GamepadEvent)

    /** Convenience: called only for button state transitions. */
    fun onButton(slot: Int, code: ButtonCode, pressed: Boolean) {}

    /** Convenience: called only for joystick moves, x/y each in [-1, 1]. */
    fun onJoystick(slot: Int, isLeft: Boolean, x: Float, y: Float) {}
}

/**
 * Simple pub-sub registry a host game/activity can use to receive events
 * directly from [com.harsh.wifigamepad.tvreceiver.network.GamepadServer]
 * without going through Android's key/input pipeline at all. This is the
 * recommended integration point for games shipped alongside this receiver.
 */
object ControllerInputBus {
    private val listeners = mutableSetOf<ControllerInputListener>()

    fun register(listener: ControllerInputListener) {
        synchronized(listeners) { listeners.add(listener) }
    }

    fun unregister(listener: ControllerInputListener) {
        synchronized(listeners) { listeners.remove(listener) }
    }

    fun dispatch(slot: Int, event: GamepadEvent) {
        val snapshot = synchronized(listeners) { listeners.toList() }
        for (l in snapshot) {
            l.onGamepadEvent(slot, event)
            when (event) {
                is GamepadEvent.ButtonDown -> l.onButton(slot, event.code, true)
                is GamepadEvent.ButtonUp -> l.onButton(slot, event.code, false)
                is GamepadEvent.JoystickLeft -> l.onJoystick(slot, true, event.x, event.y)
                is GamepadEvent.JoystickRight -> l.onJoystick(slot, false, event.x, event.y)
            }
        }
    }
}
