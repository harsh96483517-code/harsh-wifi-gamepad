package com.harsh.wifigamepad.tvreceiver.network

import com.harsh.wifigamepad.protocol.ButtonCode
import com.harsh.wifigamepad.protocol.GamepadEvent
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedWriter
import java.io.OutputStreamWriter
import kotlin.math.roundToInt

/**
 * ================================================================
 *  WHY THIS FILE EXISTS (read this before touching PPSSPP support)
 * ================================================================
 * Wi-Fi lets our receiver RECEIVE controller events reliably. It does not,
 * by itself, let an ordinary Android app inject input into an unrelated
 * third-party app such as PPSSPP - Android's security sandbox blocks that
 * for any app that isn't the platform itself. There is no unprivileged,
 * root-free way around this (confirmed: `android.permission.INJECT_EVENTS`
 * is a signature/system permission a sideloaded APK cannot hold, and the
 * companion "virtual device" APIs added in newer Android versions require
 * a system-granted role most sideloaded apps and OEM TV boxes won't have).
 *
 * The one *real*, working, non-exploit path is Android's own `uinput`
 * command-line tool (part of AOSP, used by Android's own CTS tests) which
 * creates a genuine Linux input device. Once registered, that device is
 * indistinguishable from a real USB/Bluetooth gamepad to every app on the
 * system - including PPSSPP, which already auto-detects standard
 * SOURCE_GAMEPAD/SOURCE_JOYSTICK devices with full analog stick support.
 *
 * The catch: writing to `/dev/uinput` requires root. So this class:
 *   1. Checks for root at runtime.
 *   2. If (and only if) root is available, launches `su -c "uinput -"` and
 *      drives it with the documented JSON protocol to register one virtual
 *      gamepad and stream live button/stick events into it.
 *   3. If root is NOT available, this class simply does nothing (silently
 *      inert) and the receiver falls back to the two root-free layers that
 *      already exist: the direct ControllerInputBus API (for games built to
 *      use it) and AndroidKeyTranslator (D-pad/Back/Home/Select as standard
 *      TV remote keys). PPSSPP specifically only gets full gameplay control
 *      through this root path, because PPSSPP's own source can't be changed
 *      to call our direct API - that limitation is disclosed in the README.
 */
class RootInputInjector {

    private var process: Process? = null
    private var writer: BufferedWriter? = null
    private var rooted: Boolean = false

    private var hatX = 0
    private var hatY = 0

    val isActive: Boolean get() = process != null

    /** Returns true if `su` grants root and the virtual device was registered. */
    fun start(): Boolean {
        if (isActive) return true
        rooted = checkRoot()
        if (!rooted) return false
        return try {
            val p = ProcessBuilder("su", "-c", "uinput -")
                .redirectErrorStream(true)
                .start()
            process = p
            writer = BufferedWriter(OutputStreamWriter(p.outputStream))
            sendLine(registerCommand())
            true
        } catch (e: Exception) {
            stop()
            false
        }
    }

    private fun checkRoot(): Boolean = try {
        val p = ProcessBuilder("su", "-c", "id").start()
        val output = p.inputStream.bufferedReader().readText()
        p.waitFor()
        output.contains("uid=0")
    } catch (_: Exception) {
        false
    }

    fun onEvent(event: GamepadEvent) {
        if (process == null) return
        try {
            when (event) {
                is GamepadEvent.ButtonDown -> buttonKeyOrNull(event.code)?.let { key -> injectKey(key, true) }
                is GamepadEvent.ButtonUp -> buttonKeyOrNull(event.code)?.let { key -> injectKey(key, false) }
                is GamepadEvent.JoystickLeft -> injectAxes("ABS_X" to axisValue(event.x), "ABS_Y" to axisValue(event.y))
                is GamepadEvent.JoystickRight -> injectAxes("ABS_RX" to axisValue(event.x), "ABS_RY" to axisValue(event.y))
            }
            handleDpadIfNeeded(event)
        } catch (e: Exception) {
            // Underlying su/uinput process died (e.g. root revoked mid-session); go inert.
            stop()
        }
    }

    private fun handleDpadIfNeeded(event: GamepadEvent) {
        val down = when (event) {
            is GamepadEvent.ButtonDown -> event.code
            is GamepadEvent.ButtonUp -> null
            else -> return
        }
        val up = (event as? GamepadEvent.ButtonUp)?.code
        var changed = false
        down?.let {
            when (it) {
                ButtonCode.DPAD_LEFT -> { hatX = -1; changed = true }
                ButtonCode.DPAD_RIGHT -> { hatX = 1; changed = true }
                ButtonCode.DPAD_UP -> { hatY = -1; changed = true }
                ButtonCode.DPAD_DOWN -> { hatY = 1; changed = true }
                else -> {}
            }
        }
        up?.let {
            when (it) {
                ButtonCode.DPAD_LEFT, ButtonCode.DPAD_RIGHT -> { hatX = 0; changed = true }
                ButtonCode.DPAD_UP, ButtonCode.DPAD_DOWN -> { hatY = 0; changed = true }
                else -> {}
            }
        }
        if (changed) injectAxes("ABS_HAT0X" to hatX, "ABS_HAT0Y" to hatY)
    }

    private fun axisValue(f: Float): Int = (f.coerceIn(-1f, 1f) * 32767f).roundToInt()

    private fun buttonKeyOrNull(code: ButtonCode): String? = when (code) {
        ButtonCode.A -> "BTN_SOUTH"
        ButtonCode.B -> "BTN_EAST"
        ButtonCode.X -> "BTN_WEST"
        ButtonCode.Y -> "BTN_NORTH"
        ButtonCode.L1 -> "BTN_TL"
        ButtonCode.R1 -> "BTN_TR"
        ButtonCode.L2 -> "BTN_TL2"
        ButtonCode.R2 -> "BTN_TR2"
        ButtonCode.START -> "BTN_START"
        ButtonCode.SELECT -> "BTN_SELECT"
        ButtonCode.HOME -> "BTN_MODE"
        // DPAD_* and BACK are handled via ABS_HAT0X/Y and the root-free key
        // layer respectively - not sent as gamepad buttons here.
        else -> null
    }

    private fun injectKey(key: String, down: Boolean) {
        val events = JSONArray().apply {
            put("EV_KEY"); put(key); put(if (down) 1 else 0)
            put("EV_SYN"); put("SYN_REPORT"); put(0)
        }
        sendLine(JSONObject().apply {
            put("id", 1)
            put("command", "inject")
            put("events", events)
        })
    }

    private fun injectAxes(vararg axes: Pair<String, Int>) {
        val events = JSONArray()
        for ((code, value) in axes) {
            events.put("EV_ABS"); events.put(code); events.put(value)
        }
        events.put("EV_SYN"); events.put("SYN_REPORT"); events.put(0)
        sendLine(JSONObject().apply {
            put("id", 1)
            put("command", "inject")
            put("events", events)
        })
    }

    private fun registerCommand(): JSONObject {
        fun absInfo(code: String, min: Int, max: Int) = JSONObject().apply {
            put("code", code)
            put("info", JSONObject().apply {
                put("value", 0); put("minimum", min); put("maximum", max)
                put("fuzz", 0); put("flat", if (max > 1) 16 else 0); put("resolution", 0)
            })
        }
        return JSONObject().apply {
            put("id", 1)
            put("command", "register")
            put("name", "HARSH WiFi GAMEPAD (virtual)")
            put("vid", 0x18d1) // Google's USB vendor ID, used here only as a placeholder
            put("pid", 0x2540)
            put("bus", "bluetooth")
            put("configuration", JSONArray().apply {
                put(JSONObject().put("type", "UI_SET_EVBIT").put("data", JSONArray().put("EV_KEY")))
                put(JSONObject().put("type", "UI_SET_KEYBIT").put("data", JSONArray().apply {
                    listOf(
                        "BTN_SOUTH", "BTN_EAST", "BTN_NORTH", "BTN_WEST",
                        "BTN_TL", "BTN_TR", "BTN_TL2", "BTN_TR2",
                        "BTN_START", "BTN_SELECT", "BTN_MODE"
                    ).forEach { put(it) }
                }))
                put(JSONObject().put("type", "UI_SET_EVBIT").put("data", JSONArray().put("EV_ABS")))
                put(JSONObject().put("type", "UI_SET_ABSBIT").put("data", JSONArray().apply {
                    listOf("ABS_X", "ABS_Y", "ABS_RX", "ABS_RY", "ABS_HAT0X", "ABS_HAT0Y").forEach { put(it) }
                }))
            })
            put("ff_effects_max", 0)
            put("abs_info", JSONArray().apply {
                put(absInfo("ABS_X", -32768, 32767))
                put(absInfo("ABS_Y", -32768, 32767))
                put(absInfo("ABS_RX", -32768, 32767))
                put(absInfo("ABS_RY", -32768, 32767))
                put(absInfo("ABS_HAT0X", -1, 1))
                put(absInfo("ABS_HAT0Y", -1, 1))
            })
        }
    }

    private fun sendLine(json: JSONObject) {
        val w = writer ?: return
        w.write(json.toString())
        w.newLine()
        w.flush()
    }

    /** Closes stdin, which causes `uinput` to unregister the device and exit. */
    fun stop() {
        try { writer?.close() } catch (_: Exception) {}
        try { process?.destroy() } catch (_: Exception) {}
        writer = null
        process = null
    }
}
