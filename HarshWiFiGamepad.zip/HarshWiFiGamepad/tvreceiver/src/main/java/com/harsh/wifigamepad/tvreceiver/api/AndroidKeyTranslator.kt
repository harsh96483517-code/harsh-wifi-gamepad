package com.harsh.wifigamepad.tvreceiver.api

import android.view.KeyEvent
import com.harsh.wifigamepad.protocol.ButtonCode

/**
 * Maps our [ButtonCode]s to standard Android [KeyEvent] codes, for the
 * subset of buttons that map onto real, OS-level TV-remote semantics
 * (D-pad navigation, back, home, select/enter). These work anywhere a TV
 * remote's D-pad would work (launcher, most leanback apps' own views),
 * because they are dispatched the same way a physical remote's key events
 * are - Android's normal focus/key-event system, not injection into an
 * unrelated app's private input surface.
 *
 * A/B/X/Y, L1/L2/R1/R2, joystick axes and START have no standard Android TV
 * remote equivalent, so they are NOT translated here. Games that want those
 * must integrate with [ControllerInputBus] directly.
 */
object AndroidKeyTranslator {

    fun toAndroidKeyCodeOrNull(code: ButtonCode): Int? = when (code) {
        ButtonCode.DPAD_UP -> KeyEvent.KEYCODE_DPAD_UP
        ButtonCode.DPAD_DOWN -> KeyEvent.KEYCODE_DPAD_DOWN
        ButtonCode.DPAD_LEFT -> KeyEvent.KEYCODE_DPAD_LEFT
        ButtonCode.DPAD_RIGHT -> KeyEvent.KEYCODE_DPAD_RIGHT
        ButtonCode.A -> KeyEvent.KEYCODE_DPAD_CENTER // "A" doubles as OK/Select, common TV UX
        ButtonCode.B -> KeyEvent.KEYCODE_BACK
        ButtonCode.HOME -> KeyEvent.KEYCODE_HOME
        ButtonCode.BACK -> KeyEvent.KEYCODE_BACK
        ButtonCode.START -> KeyEvent.KEYCODE_MENU
        // X, Y, L1, L2, R1, R2, SELECT: no safe standard TV-remote mapping.
        else -> null
    }
}
