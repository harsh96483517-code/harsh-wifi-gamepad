package com.harsh.wifigamepad.tvreceiver.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.harsh.wifigamepad.tvreceiver.network.ConnectedController
import com.harsh.wifigamepad.tvreceiver.network.QrCodeGenerator
import com.harsh.wifigamepad.tvreceiver.viewmodel.ReceiverUiState

@Composable
fun ReceiverScreen(
    state: ReceiverUiState,
    qrPayload: () -> String,
    onDisconnect: (ConnectedController) -> Unit,
    onToggleSound: () -> Unit,
    onOpenAccessibility: () -> Unit
) {
    val controllers = state.server.controllers
    LiquidBackground {
        Row(
            Modifier
                .fillMaxSize()
                .padding(horizontal = 48.dp, vertical = 32.dp),
            horizontalArrangement = Arrangement.spacedBy(40.dp)
        ) {
            // ---------- Left: identity, status, pairing info, controllers ----------
            Column(
                Modifier
                    .weight(1.2f)
                    .fillMaxHeight()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Row(verticalAlignment = Alignment.Bottom) {
                    Text("HARSH", color = Cyan, fontSize = 44.sp, fontWeight = FontWeight.Black)
                    Spacer(Modifier.width(14.dp))
                    Text(
                        "WiFi GAMEPAD RECEIVER",
                        color = Muted,
                        fontSize = 14.sp,
                        letterSpacing = 3.sp,
                        modifier = Modifier.padding(bottom = 9.dp)
                    )
                }

                if (controllers.isEmpty()) {
                    StatusPill(
                        if (state.server.running) "Waiting for controller…" else "Starting server…",
                        Amber
                    )
                } else {
                    StatusPill("Connected: ${controllers.first().name}", Success)
                }

                GlassCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                        Text("PAIRING PIN", color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            state.pin.forEach { ch ->
                                Box(
                                    Modifier
                                        .size(width = 60.dp, height = 74.dp)
                                        .liquidGlass(RoundedCornerShape(22.dp), elevation = 4.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(ch.toString(), color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Black)
                                }
                            }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(40.dp)) {
                            InfoBlock("IP ADDRESS", state.localIp ?: "Not on Wi-Fi")
                            InfoBlock("PORT", state.port.toString())
                        }
                    }
                }

                Text("CONTROLLERS", color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                if (controllers.isEmpty()) {
                    Text("None connected yet", color = Muted, fontSize = 14.sp)
                } else {
                    controllers.take(4).forEach { c ->
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .liquidGlass(PillShape, elevation = 4.dp)
                                .padding(start = 20.dp, end = 8.dp, top = 6.dp, bottom = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.size(10.dp).background(Success, CircleShape))
                                Spacer(Modifier.width(12.dp))
                                Column {
                                    Text(c.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                    Text(
                                        "Player ${c.slot + 1} · ${c.address.address.hostAddress}",
                                        color = Muted,
                                        fontSize = 12.sp
                                    )
                                }
                            }
                            TvPill("Disconnect", { onDisconnect(c) }, tint = Danger)
                        }
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    TvPill(
                        if (state.accessibilityOn) "TV control: ON" else "TV control: OFF – press OK",
                        onOpenAccessibility,
                        tint = if (state.accessibilityOn) Success else Amber
                    )
                    TvPill(if (state.soundEnabled) "Sound: ON" else "Sound: OFF", onToggleSound)
                }

                if (!state.accessibilityOn) {
                    Text(
                        "To enable TV control: Settings > Device Preferences > Accessibility > HARSH TV Receiver > ON",
                        color = Amber,
                        fontSize = 12.sp,
                        lineHeight = 16.sp
                    )
                }
                Text(
                    if (state.server.rootGamepadActive)
                        "Game input (PPSSPP etc.): active via root virtual gamepad."
                    else
                        "Game input for apps like PPSSPP needs a rooted TV. Menus, remote and media work without root.",
                    color = Muted,
                    fontSize = 12.sp,
                    lineHeight = 16.sp
                )
            }

            // ---------- Right: QR ----------
            Column(
                Modifier
                    .weight(0.8f)
                    .fillMaxHeight(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                GlassCard {
                    Column(Modifier.padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("SCAN TO PAIR", color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                        Spacer(Modifier.height(16.dp))
                        val bitmap = remember(state.localIp, state.pin) {
                            runCatching { QrCodeGenerator.generate(qrPayload(), 420) }.getOrNull()
                        }
                        if (bitmap != null) {
                            Image(
                                bitmap = bitmap.asImageBitmap(),
                                contentDescription = "Pairing QR code",
                                modifier = Modifier
                                    .size(240.dp)
                                    .background(Color.White, RoundedCornerShape(24.dp))
                                    .padding(14.dp)
                            )
                        }
                        Spacer(Modifier.height(16.dp))
                        Text(
                            "Open HARSH WiFi GAMEPAD on your phone\nand tap “Scan TV QR code”",
                            color = Muted,
                            fontSize = 13.sp,
                            lineHeight = 18.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun InfoBlock(label: String, value: String) {
    Column {
        Text(label, color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
        Text(value, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
    }
}
