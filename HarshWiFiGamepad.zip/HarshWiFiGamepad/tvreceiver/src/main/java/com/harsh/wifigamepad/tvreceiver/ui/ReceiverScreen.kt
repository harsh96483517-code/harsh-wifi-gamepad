package com.harsh.wifigamepad.tvreceiver.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.harsh.wifigamepad.tvreceiver.network.ConnectedController
import com.harsh.wifigamepad.tvreceiver.network.QrCodeGenerator
import com.harsh.wifigamepad.tvreceiver.viewmodel.ReceiverUiState

private val Cyan = Color(0xFF00E5FF)
private val Bg = Color(0xFF0A0A0D)
private val Muted = Color(0xFF8A8A98)
private val Success = Color(0xFF34D399)

@Composable
fun ReceiverScreen(
    state: ReceiverUiState,
    qrPayload: () -> String,
    onDisconnect: (ConnectedController) -> Unit
) {
    Row(
        Modifier
            .fillMaxSize()
            .background(Bg)
            .padding(32.dp)
    ) {
        // Left: identity + connection info
        Column(modifier = Modifier.weight(1f)) {
            Text("HARSH", color = Cyan, fontWeight = FontWeight.Black, fontSize = 40.sp)
            Text("WiFi GAMEPAD RECEIVER", color = Color(0xFFCFCFE0), fontWeight = FontWeight.Bold, fontSize = 16.sp, letterSpacing = 2.sp)
            Spacer(Modifier.height(28.dp))

            InfoRow("Status", if (state.server.running) "Waiting for controller..." else "Starting...")
            InfoRow("IP", state.localIp ?: "Not connected to Wi-Fi")
            InfoRow("Port", state.port.toString())
            InfoRow("Pairing PIN", state.pin)
            InfoRow(
                "PPSSPP / full game control",
                if (state.server.rootGamepadActive) "Active (rooted) — auto-detected by PPSSPP" else "Unavailable (device not rooted)"
            )
            state.lastEvent?.let { InfoRow("Last event", it) }

            Spacer(Modifier.height(24.dp))
            Text("CONNECTED CONTROLLERS", color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            if (state.server.controllers.isEmpty()) {
                Text("None yet", color = Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
            } else {
                LazyColumn(modifier = Modifier.padding(top = 6.dp)) {
                    items(state.server.controllers) { c ->
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .background(Color(0x1AFFFFFF), RoundedCornerShape(8.dp))
                                .padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("Connected: ${c.name}", color = Success, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text("Slot ${c.slot + 1} · ${c.address.address.hostAddress}", color = Muted, fontSize = 11.sp)
                            }
                            Text(
                                "DISCONNECT",
                                color = Color(0xFFFF4D4D),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.clickable { onDisconnect(c) }
                            )
                        }
                    }
                }
            }

            Spacer(Modifier.height(20.dp))
            Text(
                "Note: this receiver reliably reads controller input and exposes it to games\n" +
                    "that integrate with its API. It can also drive standard TV D-pad/back/home\n" +
                    "navigation. Full analog control of unmodified apps like PPSSPP requires the\n" +
                    "TV to be rooted (see README) — without root, PPSSPP will not receive\n" +
                    "gameplay input, because Android does not allow one app to inject input into\n" +
                    "another without either root or the target app's own cooperation.",
                color = Muted,
                fontSize = 11.sp,
                lineHeight = 15.sp
            )
        }

        Spacer(Modifier.width(32.dp))

        // Right: QR code for fast pairing
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(start = 24.dp)) {
            Text("SCAN TO PAIR", color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
            val bitmap = remember(state.localIp, state.pin) {
                runCatching { QrCodeGenerator.generate(qrPayload(), 420) }.getOrNull()
            }
            if (bitmap != null) {
                Image(
                    bitmap = bitmap.asImageBitmap(),
                    contentDescription = "Pairing QR code",
                    modifier = Modifier
                        .size(260.dp)
                        .background(Color.White, RoundedCornerShape(12.dp))
                        .padding(12.dp)
                )
            }
            Spacer(Modifier.height(12.dp))
            Text("Or enter the IP + PIN manually on your phone", color = Muted, fontSize = 11.sp)
        }
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(Modifier.padding(vertical = 4.dp)) {
        Text("$label: ", color = Muted, fontSize = 15.sp, fontWeight = FontWeight.Medium)
        Text(value, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
    }
}
