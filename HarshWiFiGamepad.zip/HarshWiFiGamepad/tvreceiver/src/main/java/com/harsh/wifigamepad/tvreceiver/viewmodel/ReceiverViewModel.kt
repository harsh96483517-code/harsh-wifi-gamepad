package com.harsh.wifigamepad.tvreceiver.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.harsh.wifigamepad.protocol.ProtocolConstants
import com.harsh.wifigamepad.protocol.QrPairingPayload
import com.harsh.wifigamepad.tvreceiver.network.ConnectedController
import com.harsh.wifigamepad.tvreceiver.network.GamepadServer
import com.harsh.wifigamepad.tvreceiver.network.LocalIpAddress
import com.harsh.wifigamepad.tvreceiver.network.ServerStatus
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class ReceiverUiState(
    val tvName: String = "HARSH TV RECEIVER",
    val localIp: String? = null,
    val port: Int = ProtocolConstants.DEFAULT_GAME_PORT,
    val pin: String = "----",
    val server: ServerStatus = ServerStatus(),
    val lastEvent: String? = null
)

class ReceiverViewModel(application: Application) : AndroidViewModel(application) {

    private lateinit var server: GamepadServer

    private val _uiState = MutableStateFlow(ReceiverUiState())
    val uiState: StateFlow<ReceiverUiState> = _uiState.asStateFlow()

    fun startServer() {
        if (::server.isInitialized && _uiState.value.server.running) return
        server = GamepadServer(_uiState.value.tvName)
        server.start()
        _uiState.value = _uiState.value.copy(
            localIp = LocalIpAddress.get(),
            pin = server.currentPin
        )
        viewModelScope.launch {
            server.status.collect { s -> _uiState.value = _uiState.value.copy(server = s) }
        }
        viewModelScope.launch {
            server.lastEvent.collect { e -> if (e != null) _uiState.value = _uiState.value.copy(lastEvent = e) }
        }
    }

    fun qrPayload(): String {
        val s = _uiState.value
        return QrPairingPayload(s.localIp ?: "0.0.0.0", s.port, s.pin, s.tvName).encode()
    }

    fun disconnectController(controller: ConnectedController) {
        if (::server.isInitialized) server.disconnect(controller.sessionToken)
    }

    /** Called on app exit / activity destroy to close sockets safely. */
    fun stopServer() {
        if (::server.isInitialized) server.stop()
    }

    override fun onCleared() {
        super.onCleared()
        stopServer()
    }
}
