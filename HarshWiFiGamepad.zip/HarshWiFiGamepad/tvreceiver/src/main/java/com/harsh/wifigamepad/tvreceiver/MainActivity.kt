package com.harsh.wifigamepad.tvreceiver

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.KeyEvent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import com.harsh.wifigamepad.protocol.ButtonCode
import com.harsh.wifigamepad.protocol.GamepadEvent
import com.harsh.wifigamepad.tvreceiver.api.AndroidKeyTranslator
import com.harsh.wifigamepad.tvreceiver.api.ControllerInputBus
import com.harsh.wifigamepad.tvreceiver.api.ControllerInputListener
import com.harsh.wifigamepad.tvreceiver.ui.ReceiverScreen
import com.harsh.wifigamepad.tvreceiver.viewmodel.ReceiverViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: ReceiverViewModel by viewModels()

    /**
     * Bridges incoming gamepad button presses onto Android's normal key-event
     * pipeline for the small set of buttons that have a real TV-remote
     * equivalent (see AndroidKeyTranslator). This makes D-pad/select/back/home
     * "just work" for standard Leanback UIs and for this app's own screen,
     * exactly the way a physical remote would - it is NOT a way to force
     * input into arbitrary unrelated apps.
     */
    private val keyBridgeListener = object : ControllerInputListener {
        override fun onGamepadEvent(slot: Int, event: GamepadEvent) {
            if (event is GamepadEvent.ButtonDown) viewModel.playClick()
            val (code, down) = when (event) {
                is GamepadEvent.ButtonDown -> event.code to true
                is GamepadEvent.ButtonUp -> event.code to false
                else -> return
            }
            val androidKeyCode = AndroidKeyTranslator.toAndroidKeyCodeOrNull(code) ?: return
            runOnUiThread {
                if (down) {
                    dispatchKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, androidKeyCode))
                } else {
                    dispatchKeyEvent(KeyEvent(KeyEvent.ACTION_UP, androidKeyCode))
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ControllerInputBus.register(keyBridgeListener)
        viewModel.startServer()

        setContent {
            Surface(modifier = Modifier.fillMaxSize(), color = Color(0xFF0A0A0D)) {
                val state by viewModel.uiState.collectAsState()
                ReceiverScreen(
                    state = state,
                    qrPayload = { viewModel.qrPayload() },
                    onDisconnect = { c -> viewModel.disconnectController(c) },
                    onToggleSound = { viewModel.toggleSound() },
                    onOpenAccessibility = {
                        try {
                            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                        } catch (e: Exception) {
                            try { startActivity(Intent(Settings.ACTION_SETTINGS)) } catch (_: Exception) {}
                        }
                    }
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.refreshAccessibility()
    }

    override fun onDestroy() {
        // Stop the server and close sockets safely when the app exits.
        ControllerInputBus.unregister(keyBridgeListener)
        viewModel.stopServer()
        super.onDestroy()
    }
}
