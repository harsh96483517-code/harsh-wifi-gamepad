package com.harsh.wifigamepad.tvreceiver.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

val Cyan = Color(0xFF00E5FF)
val Muted = Color(0xFF9A9AAA)
val Success = Color(0xFF34D399)
val Amber = Color(0xFFFFB020)
val Danger = Color(0xFFFF5C5C)

/** Fully rounded rectangle (pill / stadium). */
val PillShape = RoundedCornerShape(50)

fun Modifier.liquidGlass(
    shape: Shape,
    highlighted: Boolean = false,
    tint: Color = Color.White,
    elevation: Dp = 10.dp
): Modifier = this
    .shadow(elevation, shape, ambientColor = Color.Black, spotColor = Color.Black)
    .clip(shape)
    .background(
        Brush.verticalGradient(
            listOf(tint.copy(alpha = if (highlighted) 0.42f else 0.22f), tint.copy(alpha = 0.06f))
        )
    )
    .border(
        if (highlighted) 2.dp else 1.2.dp,
        Brush.verticalGradient(
            listOf(
                Color.White.copy(alpha = if (highlighted) 0.95f else 0.65f),
                Color.White.copy(alpha = 0.05f),
                Color.White.copy(alpha = 0.30f)
            )
        ),
        shape
    )
    .drawWithContent {
        drawRect(
            brush = Brush.verticalGradient(
                listOf(Color.White.copy(alpha = 0.24f), Color.Transparent),
                startY = 0f,
                endY = size.height * 0.55f
            ),
            size = Size(size.width, size.height * 0.55f)
        )
        drawContent()
    }

@Composable
fun LiquidBackground(content: @Composable BoxScope.() -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF07070B))
            .drawBehind {
                val r = size.maxDimension * 0.5f
                fun orb(c: Color, cx: Float, cy: Float) {
                    val center = Offset(size.width * cx, size.height * cy)
                    drawCircle(
                        brush = Brush.radialGradient(listOf(c, Color.Transparent), center = center, radius = r),
                        radius = r,
                        center = center
                    )
                }
                orb(Color(0x6600E5FF), 0.08f, 0.10f)
                orb(Color(0x66FF2D78), 0.95f, 0.95f)
                orb(Color(0x557C4DFF), 0.65f, 0.35f)
            },
        content = content
    )
}

/** D-pad focusable pill for TV remotes: grows and lights up when focused. */
@Composable
fun TvPill(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, tint: Color = Color.White) {
    var focused by remember { mutableStateOf(false) }
    Text(
        text = text,
        color = Color.White,
        fontSize = 15.sp,
        fontWeight = FontWeight.Bold,
        modifier = modifier
            .onFocusChanged { focused = it.isFocused }
            .scale(if (focused) 1.06f else 1f)
            .liquidGlass(PillShape, highlighted = focused, tint = if (focused) Cyan else tint, elevation = 6.dp)
            .clickable(onClick = onClick)
            .padding(horizontal = 24.dp, vertical = 12.dp)
    )
}

@Composable
fun StatusPill(text: String, color: Color, modifier: Modifier = Modifier) {
    Row(
        modifier = modifier
            .liquidGlass(PillShape, elevation = 4.dp)
            .padding(horizontal = 18.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(10.dp).background(color, CircleShape))
        Spacer(Modifier.width(10.dp))
        Text(text, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun GlassCard(modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) {
    Box(modifier = modifier.liquidGlass(RoundedCornerShape(32.dp), elevation = 8.dp), content = content)
}
