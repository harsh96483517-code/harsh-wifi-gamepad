package com.harsh.wifigamepad.tvreceiver.access

import android.accessibilityservice.AccessibilityService
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.harsh.wifigamepad.protocol.ButtonCode
import com.harsh.wifigamepad.protocol.GamepadEvent
import kotlin.math.abs

/**
 * Root-free TV navigation. Once the user enables this service in
 * Settings > Accessibility, phone D-pad / stick / A / B / Home move the TV UI.
 *  - Android 13+: uses the system D-pad global actions.
 *  - Older: moves focus with focusSearch() and clicks the focused node.
 * This controls menus and navigation. It does not deliver gameplay input to
 * games/emulators (that still needs the root virtual gamepad).
 */
class HarshAccessibilityService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())
    private val repeaters = HashMap<String, Runnable>()
    private var stickDir: Int? = null

    override fun onServiceConnected() {
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        if (instance === this) instance = null
        stopAllRepeats()
        super.onDestroy()
    }

    /** Called from the network thread for every controller event. */
    fun handle(event: GamepadEvent) {
        handler.post {
            when (event) {
                is GamepadEvent.ButtonDown -> onDown(event.code)
                is GamepadEvent.ButtonUp -> onUp(event.code)
                is GamepadEvent.JoystickLeft -> onStick(event.x, event.y)
                is GamepadEvent.JoystickRight -> {}
            }
        }
    }

    private fun onDown(code: ButtonCode) {
        when (code) {
            ButtonCode.DPAD_UP -> startRepeat("dpad", UP)
            ButtonCode.DPAD_DOWN -> startRepeat("dpad", DOWN)
            ButtonCode.DPAD_LEFT -> startRepeat("dpad", LEFT)
            ButtonCode.DPAD_RIGHT -> startRepeat("dpad", RIGHT)
            ButtonCode.A, ButtonCode.START -> center()
            ButtonCode.B, ButtonCode.BACK -> performGlobalAction(GLOBAL_ACTION_BACK)
            ButtonCode.HOME -> performGlobalAction(GLOBAL_ACTION_HOME)
            ButtonCode.SELECT -> performGlobalAction(GLOBAL_ACTION_RECENTS)
            else -> {}
        }
    }

    private fun onUp(code: ButtonCode) {
        when (code) {
            ButtonCode.DPAD_UP, ButtonCode.DPAD_DOWN, ButtonCode.DPAD_LEFT, ButtonCode.DPAD_RIGHT -> stopRepeat("dpad")
            else -> {}
        }
    }

    private fun onStick(x: Float, y: Float) {
        val dir: Int? = when {
            abs(x) < 0.6f && abs(y) < 0.6f -> null
            abs(x) > abs(y) -> if (x > 0) RIGHT else LEFT
            else -> if (y > 0) DOWN else UP
        }
        if (dir == stickDir) return
        stickDir = dir
        stopRepeat("stick")
        if (dir != null) startRepeat("stick", dir)
    }

    private fun startRepeat(key: String, dir: Int) {
        stopRepeat(key)
        move(dir)
        val r = object : Runnable {
            override fun run() {
                move(dir)
                handler.postDelayed(this, 130)
            }
        }
        repeaters[key] = r
        handler.postDelayed(r, 420)
    }

    private fun stopRepeat(key: String) {
        repeaters.remove(key)?.let { handler.removeCallbacks(it) }
    }

    private fun stopAllRepeats() {
        repeaters.values.forEach { handler.removeCallbacks(it) }
        repeaters.clear()
    }

    private fun move(dir: Int) {
        if (Build.VERSION.SDK_INT >= 33) {
            val action = when (dir) {
                UP -> GLOBAL_ACTION_DPAD_UP
                DOWN -> GLOBAL_ACTION_DPAD_DOWN
                LEFT -> GLOBAL_ACTION_DPAD_LEFT
                else -> GLOBAL_ACTION_DPAD_RIGHT
            }
            performGlobalAction(action)
        } else {
            val focusDir = when (dir) {
                UP -> View.FOCUS_UP
                DOWN -> View.FOCUS_DOWN
                LEFT -> View.FOCUS_LEFT
                else -> View.FOCUS_RIGHT
            }
            val root = rootInActiveWindow ?: return
            val current = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
                ?: root.findFocus(AccessibilityNodeInfo.FOCUS_ACCESSIBILITY)
            val next = current?.focusSearch(focusDir)
            next?.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        }
    }

    private fun center() {
        if (Build.VERSION.SDK_INT >= 33) {
            performGlobalAction(GLOBAL_ACTION_DPAD_CENTER)
        } else {
            val root = rootInActiveWindow ?: return
            val current = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
                ?: root.findFocus(AccessibilityNodeInfo.FOCUS_ACCESSIBILITY)
            current?.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        }
    }

    companion object {
        private const val UP = 0
        private const val DOWN = 1
        private const val LEFT = 2
        private const val RIGHT = 3

        @Volatile
        var instance: HarshAccessibilityService? = null
    }
}
