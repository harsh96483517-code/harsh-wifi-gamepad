package com.harsh.wifigamepad.controller.ui.theme

import androidx.compose.ui.graphics.Color

// HARSH premium black gaming palette
val HarshBackground = Color(0xFF0A0A0D)
val HarshSurface = Color(0xFF15151B)
val HarshSurfaceGlass = Color(0x33FFFFFF)
val HarshAccent = Color(0xFF00E5FF)      // electric cyan
val HarshAccentAlt = Color(0xFFFF2D78)   // magenta accent for A/B/X/Y highlights
val HarshOnBackground = Color(0xFFF2F2F7)
val HarshMuted = Color(0xFF8A8A98)
val HarshDanger = Color(0xFFFF4D4D)
val HarshSuccess = Color(0xFF34D399)
val HarshButtonFace = Color(0xFF1E1E26)
val HarshButtonFacePressed = Color(0xFF2A2A35)
val HarshStickBase = Color(0xFF17171E)
val HarshStickKnob = Color(0xFF2C2C38)
