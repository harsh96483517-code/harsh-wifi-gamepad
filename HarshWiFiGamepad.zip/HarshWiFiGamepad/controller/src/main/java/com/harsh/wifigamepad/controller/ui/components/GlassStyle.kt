package com.harsh.wifigamepad.controller.ui.components

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** iOS-style "liquid glass": translucent tinted fill, bright specular rim, top gloss, soft shadow. */
fun Modifier.liquidGlass(
    shape: Shape,
    pressed: Boolean = false,
    tint: Color = Color.White,
    elevation: Dp = 10.dp
): Modifier = this
    .shadow(if (pressed) 2.dp else elevation, shape, ambientColor = Color.Black, spotColor = Color.Black)
    .clip(shape)
    .background(
        Brush.verticalGradient(
            listOf(tint.copy(alpha = if (pressed) 0.40f else 0.24f), tint.copy(alpha = 0.06f))
        )
    )
    .border(
        1.2.dp,
        Brush.verticalGradient(
            listOf(Color.White.copy(alpha = 0.70f), Color.White.copy(alpha = 0.05f), Color.White.copy(alpha = 0.30f))
        ),
        shape
    )
    .drawWithContent {
        drawRect(
            brush = Brush.verticalGradient(
                listOf(Color.White.copy(alpha = 0.26f), Color.Transparent),
                startY = 0f,
                endY = size.height * 0.55f
            ),
            size = Size(size.width, size.height * 0.55f)
        )
        drawContent()
    }

/** Dark backdrop with soft colour orbs so the glass has something to refract. */
@Composable
fun LiquidBackground(content: @Composable BoxScope.() -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF07070B))
            .drawBehind {
                val r = size.maxDimension * 0.55f
                fun orb(c: Color, cx: Float, cy: Float) {
                    val center = Offset(size.width * cx, size.height * cy)
                    drawCircle(
                        brush = Brush.radialGradient(listOf(c, Color.Transparent), center = center, radius = r),
                        radius = r,
                        center = center
                    )
                }
                orb(Color(0x6600E5FF), 0.10f, 0.10f)
                orb(Color(0x66FF2D78), 0.95f, 0.95f)
                orb(Color(0x557C4DFF), 0.60f, 0.40f)
            },
        content = content
    )
}

/** Press-and-hold glass button with a springy scale animation. */
@Composable
fun GlassButton(
    shape: Shape,
    modifier: Modifier = Modifier,
    tint: Color = Color.White,
    onDown: () -> Unit,
    onUp: () -> Unit,
    content: @Composable BoxScope.(pressed: Boolean) -> Unit
) {
    var pressed by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(
        if (pressed) 0.92f else 1f,
        spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
        label = "glassScale"
    )
    val downCb by rememberUpdatedState(onDown)
    val upCb by rememberUpdatedState(onUp)
    Box(
        modifier = modifier
            .scale(scale)
            .liquidGlass(shape, pressed, tint)
            .pointerInput(Unit) {
                awaitPointerEventScope {
                    while (true) {
                        awaitFirstDown()
                        pressed = true
                        downCb()
                        var anyDown = true
                        while (anyDown) {
                            val ev = awaitPointerEvent()
                            anyDown = ev.changes.any { it.pressed }
                        }
                        pressed = false
                        upCb()
                    }
                }
            },
        contentAlignment = Alignment.Center
    ) {
        this.content(pressed)
    }
}

@Composable
fun GlassChip(text: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Text(
        text = text,
        color = Color.White,
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold,
        modifier = modifier
            .liquidGlass(RoundedCornerShape(50), elevation = 4.dp)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp)
    )
}
