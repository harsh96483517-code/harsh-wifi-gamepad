package com.harsh.wifigamepad.controller

import android.app.Application

class HarshApplication : Application()
