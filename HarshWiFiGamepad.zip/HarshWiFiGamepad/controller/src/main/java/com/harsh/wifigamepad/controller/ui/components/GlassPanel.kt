package com.harsh.wifigamepad.controller.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.dp
import com.harsh.wifigamepad.controller.ui.theme.HarshSurfaceGlass

/** A frosted, glass-like panel: subtle gradient fill + soft border, no elevation shadow spam. */
@Composable
fun GlassPanel(
    modifier: Modifier = Modifier,
    shape: Shape = RectangleShape,
    content: @Composable () -> Unit
) {
    Box(
        modifier = modifier
            .clip(shape)
            .background(
                Brush.verticalGradient(
                    listOf(HarshSurfaceGlass, Color(0x14FFFFFF))
                )
            )
            .border(1.dp, Color(0x26FFFFFF), shape)
            .padding(2.dp)
    ) {
        content()
    }
}
