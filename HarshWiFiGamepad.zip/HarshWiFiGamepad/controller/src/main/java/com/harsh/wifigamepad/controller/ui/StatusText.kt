package com.harsh.wifigamepad.controller.ui

import com.harsh.wifigamepad.controller.network.ConnectionState
import com.harsh.wifigamepad.controller.viewmodel.ControllerUiState

fun ControllerUiState.connectionLabel(): String = when (connection.state) {
    ConnectionState.CONNECTED -> "Connected" + (connection.latencyMs?.let { " · ${it} ms" } ?: "")
    ConnectionState.CONNECTING -> "Connecting…"
    ConnectionState.RECONNECTING -> "Reconnecting…"
    ConnectionState.DISCOVERING -> "Searching for TVs…"
    ConnectionState.REJECTED -> "Connection rejected"
    ConnectionState.DISCONNECTED -> "Disconnected"
    ConnectionState.IDLE -> "Not connected"
}
