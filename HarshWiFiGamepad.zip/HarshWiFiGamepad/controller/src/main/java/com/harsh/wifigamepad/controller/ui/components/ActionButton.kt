package com.harsh.wifigamepad.controller.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.waitForUpOrCancel
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.harsh.wifigamepad.controller.ui.theme.HarshButtonFace
import com.harsh.wifigamepad.controller.ui.theme.HarshButtonFacePressed
import com.harsh.wifigamepad.protocol.ButtonCode

/** A single circular face button. Animates a quick scale-down + glow on press. */
@Composable
fun ActionButton(
    label: String,
    code: ButtonCode,
    sizeDp: Dp,
    accentColor: Color,
    onDown: (ButtonCode) -> Unit,
    onUp: (ButtonCode) -> Unit,
    shape: Shape = CircleShape,
    modifier: Modifier = Modifier
) {
    var pressed by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (pressed) 0.88f else 1f, tween(80), label = "btnScale")

    Box(
        modifier = modifier
            .size(sizeDp)
            .scale(scale)
            .shadow(if (pressed) 2.dp else 6.dp, shape)
            .background(if (pressed) HarshButtonFacePressed else HarshButtonFace, shape)
            .pointerInput(code) {
                awaitPointerEventScope {
                    while (true) {
                        awaitFirstDown()
                        pressed = true
                        onDown(code)
                        waitForUpOrCancel()
                        pressed = false
                        onUp(code)
                    }
                }
            },
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            color = if (pressed) accentColor else accentColor.copy(alpha = 0.85f),
            fontWeight = FontWeight.Black,
            fontSize = (sizeDp.value * 0.32f).sp
        )
    }
}

/** A small rectangular button used for shoulder buttons (L1/L2/R1/R2) and system keys. */
@Composable
fun RectButton(
    label: String,
    code: ButtonCode,
    onDown: (ButtonCode) -> Unit,
    onUp: (ButtonCode) -> Unit,
    modifier: Modifier = Modifier
) {
    var pressed by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (pressed) 0.92f else 1f, tween(80), label = "rectScale")
    Box(
        modifier = modifier
            .scale(scale)
            .background(if (pressed) HarshButtonFacePressed else HarshButtonFace, RoundedCornerShape(8.dp))
            .pointerInput(code) {
                awaitPointerEventScope {
                    while (true) {
                        awaitFirstDown()
                        pressed = true
                        onDown(code)
                        waitForUpOrCancel()
                        pressed = false
                        onUp(code)
                    }
                }
            },
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = Color(0xFFCFCFE0), fontWeight = FontWeight.Bold, fontSize = 12.sp)
    }
}
