package com.harsh.wifigamepad.controller.ui.components

import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.harsh.wifigamepad.protocol.ButtonCode

/** Round liquid-glass face button (A/B/X/Y), tinted with [accentColor]. */
@Composable
fun ActionButton(
    label: String,
    code: ButtonCode,
    sizeDp: Dp,
    accentColor: Color,
    onDown: (ButtonCode) -> Unit,
    onUp: (ButtonCode) -> Unit,
    shape: Shape = CircleShape,
    modifier: Modifier = Modifier
) {
    GlassButton(
        shape = shape,
        modifier = modifier.size(sizeDp),
        tint = accentColor,
        onDown = { onDown(code) },
        onUp = { onUp(code) }
    ) {
        Text(label, color = Color.White, fontWeight = FontWeight.Black, fontSize = (sizeDp.value * 0.34f).sp)
    }
}

/** Glass pill for shoulder / system buttons. Caller sets the size. */
@Composable
fun RectButton(
    label: String,
    code: ButtonCode,
    onDown: (ButtonCode) -> Unit,
    onUp: (ButtonCode) -> Unit,
    modifier: Modifier = Modifier
) {
    GlassButton(
        shape = PillShape,
        modifier = modifier,
        onDown = { onDown(code) },
        onUp = { onUp(code) }
    ) {
        Text(label, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
    }
}
