package com.harsh.wifigamepad.controller.viewmodel

import android.app.Application
import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.harsh.wifigamepad.controller.data.SettingsStore
import com.harsh.wifigamepad.controller.network.ConnectionState
import com.harsh.wifigamepad.controller.network.ConnectionStatus
import com.harsh.wifigamepad.controller.network.DiscoveredTv
import com.harsh.wifigamepad.controller.network.GamepadClient
import com.harsh.wifigamepad.protocol.ButtonCode
import com.harsh.wifigamepad.protocol.GamepadEvent
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class ControllerUiState(
    val controllerName: String = "HARSH PHONE",
    val buttonSize: Float = 1.0f,
    val stickSensitivity: Float = 1.0f,
    val vibrationEnabled: Boolean = true,
    val autoReconnect: Boolean = true,
    val accent: String = "cyan",
    val layoutMode: String = "default",
    val discovered: List<DiscoveredTv> = emptyList(),
    val connection: ConnectionStatus = ConnectionStatus()
)

class ControllerViewModel(application: Application) : AndroidViewModel(application) {

    private val settings = SettingsStore(application)
    private lateinit var client: GamepadClient
    private var controllerId: String = ""

    private val _uiState = MutableStateFlow(ControllerUiState())
    val uiState: StateFlow<ControllerUiState> = _uiState.asStateFlow()

    private val vibrator: Vibrator? by lazy {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vm = application.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
            vm?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            application.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }
    }

    init {
        viewModelScope.launch {
            controllerId = settings.getOrCreateControllerId()
            client = GamepadClient(controllerId, _uiState.value.controllerName)
            observeSettings()
            observeClient()
        }
    }

    private fun observeSettings() {
        viewModelScope.launch { settings.controllerName.collect { name -> _uiState.value = _uiState.value.copy(controllerName = name) } }
        viewModelScope.launch { settings.buttonSize.collect { v -> _uiState.value = _uiState.value.copy(buttonSize = v) } }
        viewModelScope.launch { settings.stickSensitivity.collect { v -> _uiState.value = _uiState.value.copy(stickSensitivity = v) } }
        viewModelScope.launch { settings.vibrationEnabled.collect { v -> _uiState.value = _uiState.value.copy(vibrationEnabled = v) } }
        viewModelScope.launch { settings.autoReconnect.collect { v -> _uiState.value = _uiState.value.copy(autoReconnect = v) } }
        viewModelScope.launch { settings.accent.collect { v -> _uiState.value = _uiState.value.copy(accent = v) } }
        viewModelScope.launch { settings.layoutMode.collect { v -> _uiState.value = _uiState.value.copy(layoutMode = v) } }
    }

    private fun observeClient() {
        viewModelScope.launch { client.discovered.collect { list -> _uiState.value = _uiState.value.copy(discovered = list) } }
        viewModelScope.launch { client.status.collect { s -> _uiState.value = _uiState.value.copy(connection = s) } }
    }

    fun startDiscovery() = client.discover()

    fun connectTo(tv: DiscoveredTv, pin: String) {
        viewModelScope.launch {
            settings.setLastTv(tv.ip, tv.port)
            client.connect(tv.ip, tv.port, pin, _uiState.value.autoReconnect)
        }
    }

    fun connectManually(ip: String, port: Int, pin: String) {
        viewModelScope.launch {
            settings.setLastTv(ip, port)
            client.connect(ip, port, pin, _uiState.value.autoReconnect)
        }
    }

    fun disconnect() = client.disconnect()

    fun onButtonDown(code: ButtonCode) {
        client.sendEvent(GamepadEvent.ButtonDown(code))
        vibrate(short = true)
    }

    fun onButtonUp(code: ButtonCode) {
        client.sendEvent(GamepadEvent.ButtonUp(code))
    }

    fun onLeftStick(x: Float, y: Float) {
        val s = _uiState.value.stickSensitivity
        client.sendEvent(GamepadEvent.JoystickLeft((x * s).coerceIn(-1f, 1f), (y * s).coerceIn(-1f, 1f)))
    }

    fun onRightStick(x: Float, y: Float) {
        val s = _uiState.value.stickSensitivity
        client.sendEvent(GamepadEvent.JoystickRight((x * s).coerceIn(-1f, 1f), (y * s).coerceIn(-1f, 1f)))
    }

    private fun vibrate(short: Boolean) {
        if (!_uiState.value.vibrationEnabled) return
        val v = vibrator ?: return
        val durationMs = if (short) 12L else 40L
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            v.vibrate(VibrationEffect.createOneShot(durationMs, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            @Suppress("DEPRECATION")
            v.vibrate(durationMs)
        }
    }

    // --- Settings mutators exposed to the Settings screen ---
    fun setControllerName(name: String) = viewModelScope.launch { settings.setControllerName(name) }
    fun setButtonSize(scale: Float) = viewModelScope.launch { settings.setButtonSize(scale) }
    fun setStickSensitivity(scale: Float) = viewModelScope.launch { settings.setStickSensitivity(scale) }
    fun setVibrationEnabled(enabled: Boolean) = viewModelScope.launch { settings.setVibrationEnabled(enabled) }
    fun setAutoReconnect(enabled: Boolean) = viewModelScope.launch { settings.setAutoReconnect(enabled) }
    fun setAccent(accent: String) = viewModelScope.launch { settings.setAccent(accent) }
    fun setLayoutMode(mode: String) = viewModelScope.launch { settings.setLayoutMode(mode) }

    override fun onCleared() {
        super.onCleared()
        if (::client.isInitialized) client.disconnect()
    }
}
