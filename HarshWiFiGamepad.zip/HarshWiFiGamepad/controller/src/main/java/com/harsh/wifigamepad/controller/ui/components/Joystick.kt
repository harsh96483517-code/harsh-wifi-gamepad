package com.harsh.wifigamepad.controller.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.harsh.wifigamepad.controller.ui.theme.HarshAccent
import com.harsh.wifigamepad.controller.ui.theme.HarshStickBase
import com.harsh.wifigamepad.controller.ui.theme.HarshStickKnob
import kotlinx.coroutines.launch
import kotlin.math.sqrt

/**
 * A virtual analog stick. Reports normalized [-1, 1] x/y on every move, and
 * (0, 0) when released. Radius scales with [sizeDp] so the "button size"
 * setting also affects stick footprint.
 */
@Composable
fun Joystick(
    sizeDp: Dp = 128.dp,
    onMove: (x: Float, y: Float) -> Unit,
    modifier: Modifier = Modifier
) {
    val scope = rememberCoroutineScope()
    val knobOffset = remember { Animatable(Offset.Zero, Offset.VectorConverter) }
    var baseRadiusPx by remember { mutableStateOf(0f) }

    Box(
        modifier = modifier
            .size(sizeDp)
            .shadow(8.dp, CircleShape, clip = false)
            .background(HarshStickBase, CircleShape)
            .pointerInput(Unit) {
                baseRadiusPx = size.minDimension / 2f
                detectDragGestures(
                    onDragStart = { },
                    onDragEnd = {
                        scope.launch {
                            knobOffset.animateTo(Offset.Zero)
                            onMove(0f, 0f)
                        }
                    },
                    onDragCancel = {
                        scope.launch {
                            knobOffset.animateTo(Offset.Zero)
                            onMove(0f, 0f)
                        }
                    },
                    onDrag = { change, dragAmount ->
                        change.consume()
                        val proposed = knobOffset.targetValue + dragAmount
                        val dist = sqrt(proposed.x * proposed.x + proposed.y * proposed.y)
                        val maxDist = baseRadiusPx * 0.62f
                        val clamped = if (dist > maxDist && dist > 0f) {
                            proposed * (maxDist / dist)
                        } else proposed
                        scope.launch { knobOffset.snapTo(clamped) }
                        val nx = (clamped.x / maxDist).coerceIn(-1f, 1f)
                        val ny = (clamped.y / maxDist).coerceIn(-1f, 1f)
                        onMove(nx, ny)
                    }
                )
            }
    ) {
        Box(
            modifier = Modifier
                .size(sizeDp * 0.46f)
                .offset { androidx.compose.ui.unit.IntOffset(knobOffset.value.x.toInt(), knobOffset.value.y.toInt()) }
                .align(androidx.compose.ui.Alignment.Center)
                .shadow(6.dp, CircleShape)
                .background(HarshStickKnob, CircleShape)
                .background(HarshAccent.copy(alpha = 0.08f), CircleShape)
        )
    }
}
