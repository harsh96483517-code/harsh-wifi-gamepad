package com.harsh.wifigamepad.controller.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.harsh.wifigamepad.controller.ui.components.GlassChip
import com.harsh.wifigamepad.controller.ui.components.GlassPanel
import com.harsh.wifigamepad.controller.ui.components.PillShape
import com.harsh.wifigamepad.controller.ui.theme.HarshMuted
import com.harsh.wifigamepad.controller.ui.theme.LocalAccent
import com.harsh.wifigamepad.controller.viewmodel.ControllerUiState

@Composable
fun SettingsScreen(
    state: ControllerUiState,
    onBack: () -> Unit,
    onNameChange: (String) -> Unit,
    onButtonSizeChange: (Float) -> Unit,
    onSensitivityChange: (Float) -> Unit,
    onVibrationChange: (Boolean) -> Unit,
    onSoundChange: (Boolean) -> Unit,
    onAutoReconnectChange: (Boolean) -> Unit,
    onAccentChange: (String) -> Unit
) {
    val accent = LocalAccent.current
    var name by remember(state.controllerName) { mutableStateOf(state.controllerName) }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            GlassChip("← BACK", onBack)
            Spacer(Modifier.width(14.dp))
            Text("Settings", color = Color.White, fontWeight = FontWeight.Black, fontSize = 24.sp)
        }

        Section("CONTROLLER") {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it; onNameChange(it) },
                label = { Text("Controller name") },
                singleLine = true,
                shape = PillShape,
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = accent,
                    unfocusedBorderColor = Color(0x55FFFFFF),
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    focusedLabelColor = accent,
                    unfocusedLabelColor = HarshMuted,
                    cursorColor = accent
                )
            )
        }

        Section("GAMEPAD LAYOUT") {
            LabeledSlider("Button size", "${"%.0f".format(state.buttonSize * 100)}%", state.buttonSize, 0.7f..1.4f, onButtonSizeChange)
            Spacer(Modifier.height(8.dp))
            LabeledSlider("Joystick sensitivity", "${"%.1f".format(state.stickSensitivity)}x", state.stickSensitivity, 0.5f..2.0f, onSensitivityChange)
        }

        Section("FEEDBACK") {
            ToggleRow("Vibration", state.vibrationEnabled, onVibrationChange)
            ToggleRow("Button click sound", state.soundEnabled, onSoundChange)
        }

        Section("CONNECTION") {
            ToggleRow("Auto reconnect", state.autoReconnect, onAutoReconnectChange)
        }

        Section("THEME") {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                listOf("cyan" to Color(0xFF00E5FF), "magenta" to Color(0xFFFF2D78), "green" to Color(0xFF34D399))
                    .forEach { (key, color) ->
                        val selected = state.accent == key
                        Box(
                            modifier = Modifier
                                .size(width = 64.dp, height = 36.dp)
                                .clip(PillShape)
                                .background(color)
                                .border(if (selected) 3.dp else 0.dp, Color.White, PillShape)
                                .clickable { onAccentChange(key) }
                        )
                    }
            }
        }

        Section("ABOUT") {
            Text("HARSH WiFi GAMEPAD", color = Color.White, fontWeight = FontWeight.Bold)
            Text("Version 1.0 · Local Wi-Fi only · No Bluetooth · No cloud", color = HarshMuted, fontSize = 12.sp)
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun Section(title: String, content: @Composable () -> Unit) {
    Text(
        title,
        color = HarshMuted,
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 1.sp,
        modifier = Modifier.padding(top = 20.dp, bottom = 8.dp, start = 6.dp)
    )
    GlassPanel(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(28.dp)) {
        Column(Modifier.padding(16.dp)) { content() }
    }
}

@Composable
private fun LabeledSlider(
    label: String,
    valueText: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onChange: (Float) -> Unit
) {
    val accent = LocalAccent.current
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = Color.White, fontSize = 14.sp)
        Text(valueText, color = accent, fontSize = 14.sp, fontWeight = FontWeight.Bold)
    }
    Slider(
        value = value,
        valueRange = range,
        onValueChange = onChange,
        colors = SliderDefaults.colors(
            thumbColor = accent,
            activeTrackColor = accent,
            inactiveTrackColor = Color(0x33FFFFFF)
        )
    )
}

@Composable
private fun ToggleRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    val accent = LocalAccent.current
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = Color.White, fontSize = 14.sp)
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.Black,
                checkedTrackColor = accent,
                uncheckedTrackColor = Color(0x33FFFFFF),
                uncheckedThumbColor = Color.White
            )
        )
    }
}
