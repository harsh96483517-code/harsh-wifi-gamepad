package com.harsh.wifigamepad.controller.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.harsh.wifigamepad.controller.ui.components.GlassPanel
import com.harsh.wifigamepad.controller.ui.theme.HarshAccent
import com.harsh.wifigamepad.controller.ui.theme.HarshBackground
import com.harsh.wifigamepad.controller.ui.theme.HarshMuted
import com.harsh.wifigamepad.controller.viewmodel.ControllerUiState

@Composable
fun SettingsScreen(
    state: ControllerUiState,
    onBack: () -> Unit,
    onNameChange: (String) -> Unit,
    onButtonSizeChange: (Float) -> Unit,
    onSensitivityChange: (Float) -> Unit,
    onVibrationChange: (Boolean) -> Unit,
    onSoundChange: (Boolean) -> Unit,
    onAutoReconnectChange: (Boolean) -> Unit,
    onAccentChange: (String) -> Unit
) {
    var name by remember(state.controllerName) { mutableStateOf(state.controllerName) }

    Column(
        Modifier
            .background(HarshBackground)
            .padding(20.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Row(
            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
            modifier = Modifier.clickable { onBack() }
        ) {
            Text("←", color = HarshAccent, fontWeight = FontWeight.Bold, fontSize = 20.sp,
                modifier = Modifier.padding(end = 8.dp))
            Text("SETTINGS", color = Color.White, fontWeight = FontWeight.Black, fontSize = 20.sp)
        }
        Text("Tap to go back", color = HarshMuted, fontSize = 11.sp,
            modifier = Modifier.padding(bottom = 16.dp))

        SectionCard("Controller name") {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it; onNameChange(it) },
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = HarshAccent)
            )
        }

        SectionCard("Button size") {
            SliderRow(
                value = state.buttonSize,
                range = 0.7f..1.4f,
                label = "${"%.0f".format(state.buttonSize * 100)}%",
                onChange = onButtonSizeChange
            )
        }

        SectionCard("Joystick sensitivity") {
            SliderRow(
                value = state.stickSensitivity,
                range = 0.5f..2.0f,
                label = "${"%.1f".format(state.stickSensitivity)}x",
                onChange = onSensitivityChange
            )
        }

        SectionCard("Vibration feedback") {
            ToggleRow("Vibrate on button press", state.vibrationEnabled, onVibrationChange)
        }

        SectionCard("Sound") {
            ToggleRow("Button click sound", state.soundEnabled, onSoundChange)
        }

        SectionCard("Connection settings") {
            ToggleRow("Auto reconnect", state.autoReconnect, onAutoReconnectChange)
        }

        SectionCard("Theme") {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                listOf("cyan" to Color(0xFF00E5FF), "magenta" to Color(0xFFFF2D78), "green" to Color(0xFF34D399))
                    .forEach { (key, color) ->
                        val selected = state.accent == key
                        Box(
                            modifier = Modifier
                                .height(36.dp)
                                .background(color, RoundedCornerShape(8.dp))
                                .padding(horizontal = if (selected) 18.dp else 14.dp)
                                .clickable { onAccentChange(key) }
                        )
                    }
            }
            Spacer(Modifier.height(4.dp))
            Text("Accent: ${state.accent}", color = HarshMuted, fontSize = 12.sp)
        }

        SectionCard("About") {
            Text("HARSH WiFi GAMEPAD", color = Color.White, fontWeight = FontWeight.Bold)
            Text("Local Wi-Fi controller · no Bluetooth · no cloud", color = HarshMuted, fontSize = 12.sp)
            Text("Version 1.0 (MVP)", color = HarshMuted, fontSize = 12.sp)
        }

        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun SectionCard(title: String, content: @Composable () -> Unit) {
    Text(title.uppercase(), color = HarshMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(top = 16.dp, bottom = 6.dp))
    GlassPanel(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.padding(14.dp)) { content() }
    }
}

@Composable
private fun SliderRow(value: Float, range: ClosedFloatingPointRange<Float>, label: String, onChange: (Float) -> Unit) {
    Column {
        Slider(
            value = value,
            valueRange = range,
            onValueChange = onChange,
            colors = SliderDefaults.colors(thumbColor = HarshAccent, activeTrackColor = HarshAccent)
        )
        Text(label, color = Color.White, fontSize = 12.sp)
    }
}

@Composable
private fun ToggleRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
        Text(label, color = Color.White, fontSize = 14.sp)
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(checkedThumbColor = HarshAccent, checkedTrackColor = HarshAccent.copy(alpha = 0.4f))
        )
    }
}
