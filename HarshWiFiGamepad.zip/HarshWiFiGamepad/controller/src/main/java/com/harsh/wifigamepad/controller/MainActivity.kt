package com.harsh.wifigamepad.controller

import android.app.Activity
import android.content.pm.ActivityInfo
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import com.harsh.wifigamepad.controller.network.ConnectionState
import com.harsh.wifigamepad.controller.ui.ControllerScreen
import com.harsh.wifigamepad.controller.ui.PairingScreen
import com.harsh.wifigamepad.controller.ui.RemoteScreen
import com.harsh.wifigamepad.controller.ui.SettingsScreen
import com.harsh.wifigamepad.controller.ui.components.LiquidBackground
import com.harsh.wifigamepad.controller.ui.theme.HarshBackground
import com.harsh.wifigamepad.controller.ui.theme.HarshWiFiGamepadTheme
import com.harsh.wifigamepad.controller.viewmodel.ControllerViewModel

private enum class Screen { PAIRING, REMOTE, GAMEPAD, SETTINGS }

class MainActivity : ComponentActivity() {

    private val viewModel: ControllerViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            HarshWiFiGamepadTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = HarshBackground) {
                    LiquidBackground { HarshApp(viewModel) }
                }
            }
        }
    }
}

@Composable
private fun HarshApp(viewModel: ControllerViewModel) {
    val state by viewModel.uiState.collectAsState()
    var screen by remember { mutableStateOf(Screen.PAIRING) }
    var mode by remember { mutableStateOf(Screen.REMOTE) } // last used: REMOTE or GAMEPAD
    val activity = LocalContext.current as? Activity

    // Remote = portrait, Gamepad = landscape, everything else portrait.
    LaunchedEffect(screen) {
        activity?.requestedOrientation = when (screen) {
            Screen.GAMEPAD -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            else -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
        }
    }

    val connectionState = state.connection.state
    LaunchedEffect(connectionState) {
        if (connectionState == ConnectionState.CONNECTED && screen == Screen.PAIRING) {
            screen = mode
        }
    }

    when (screen) {
        Screen.PAIRING -> PairingScreen(
            state = state,
            onStartDiscovery = viewModel::startDiscovery,
            onConnect = { tv, pin -> viewModel.connectTo(tv, pin) },
            onConnectManual = { ip, port, pin -> viewModel.connectManually(ip, port, pin) }
        )
        Screen.REMOTE -> RemoteScreen(
            state = state,
            onButtonDown = viewModel::onButtonDown,
            onButtonUp = viewModel::onButtonUp,
            onSwitchMode = {
                mode = Screen.GAMEPAD
                screen = Screen.GAMEPAD
            },
            onOpenSettings = { screen = Screen.SETTINGS },
            onDisconnect = {
                viewModel.disconnect()
                screen = Screen.PAIRING
            }
        )
        Screen.GAMEPAD -> ControllerScreen(
            state = state,
            onButtonDown = viewModel::onButtonDown,
            onButtonUp = viewModel::onButtonUp,
            onLeftStick = viewModel::onLeftStick,
            onRightStick = viewModel::onRightStick,
            onOpenSettings = { screen = Screen.SETTINGS },
            onDisconnect = {
                viewModel.disconnect()
                screen = Screen.PAIRING
            },
            onSwitchMode = {
                mode = Screen.REMOTE
                screen = Screen.REMOTE
            }
        )
        Screen.SETTINGS -> SettingsScreen(
            state = state,
            onBack = {
                screen = if (state.connection.state == ConnectionState.CONNECTED) mode else Screen.PAIRING
            },
            onNameChange = viewModel::setControllerName,
            onButtonSizeChange = viewModel::setButtonSize,
            onSensitivityChange = viewModel::setStickSensitivity,
            onVibrationChange = viewModel::setVibrationEnabled,
            onSoundChange = viewModel::setSoundEnabled,
            onAutoReconnectChange = viewModel::setAutoReconnect,
            onAccentChange = viewModel::setAccent
        )
    }
}
