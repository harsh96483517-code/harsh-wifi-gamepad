package com.harsh.wifigamepad.controller

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.harsh.wifigamepad.controller.network.ConnectionState
import com.harsh.wifigamepad.controller.ui.ControllerScreen
import com.harsh.wifigamepad.controller.ui.PairingScreen
import com.harsh.wifigamepad.controller.ui.SettingsScreen
import com.harsh.wifigamepad.controller.ui.theme.HarshBackground
import com.harsh.wifigamepad.controller.ui.theme.HarshWiFiGamepadTheme
import com.harsh.wifigamepad.controller.viewmodel.ControllerViewModel

private enum class Screen { PAIRING, CONTROLLER, SETTINGS }

class MainActivity : ComponentActivity() {

    private val viewModel: ControllerViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            HarshWiFiGamepadTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = HarshBackground) {
                    HarshApp(viewModel)
                }
            }
        }
    }
}

@Composable
private fun HarshApp(viewModel: ControllerViewModel) {
    val state by viewModel.uiState.collectAsState()
    var screen by remember { mutableStateOf(Screen.PAIRING) }

    // Auto-advance to the controller screen once connected; fall back to
    // pairing if the connection is lost and auto-reconnect is exhausted.
    val connectionState = state.connection.state
    androidx.compose.runtime.LaunchedEffect(connectionState) {
        if (connectionState == ConnectionState.CONNECTED && screen == Screen.PAIRING) {
            screen = Screen.CONTROLLER
        }
    }

    when (screen) {
        Screen.PAIRING -> PairingScreen(
            state = state,
            onStartDiscovery = viewModel::startDiscovery,
            onConnect = { tv, pin -> viewModel.connectTo(tv, pin) },
            onConnectManual = { ip, port, pin -> viewModel.connectManually(ip, port, pin) }
        )
        Screen.CONTROLLER -> ControllerScreen(
            state = state,
            onButtonDown = viewModel::onButtonDown,
            onButtonUp = viewModel::onButtonUp,
            onLeftStick = viewModel::onLeftStick,
            onRightStick = viewModel::onRightStick,
            onOpenSettings = { screen = Screen.SETTINGS },
            onDisconnect = {
                viewModel.disconnect()
                screen = Screen.PAIRING
            }
        )
        Screen.SETTINGS -> SettingsScreen(
            state = state,
            onBack = { screen = if (state.connection.state == ConnectionState.CONNECTED) Screen.CONTROLLER else Screen.PAIRING },
            onNameChange = viewModel::setControllerName,
            onButtonSizeChange = viewModel::setButtonSize,
            onSensitivityChange = viewModel::setStickSensitivity,
            onVibrationChange = viewModel::setVibrationEnabled,
            onSoundChange = viewModel::setSoundEnabled,
            onAutoReconnectChange = viewModel::setAutoReconnect,
            onAccentChange = viewModel::setAccent
        )
    }
}
