package com.harsh.wifigamepad.controller.network

import com.harsh.wifigamepad.protocol.ByeFrame
import com.harsh.wifigamepad.protocol.DiscoveryRequest
import com.harsh.wifigamepad.protocol.DiscoveryResponse
import com.harsh.wifigamepad.protocol.GamepadEvent
import com.harsh.wifigamepad.protocol.HelloFrame
import com.harsh.wifigamepad.protocol.InputFrame
import com.harsh.wifigamepad.protocol.PingFrame
import com.harsh.wifigamepad.protocol.PongFrame
import com.harsh.wifigamepad.protocol.ProtocolConstants
import com.harsh.wifigamepad.protocol.RejectFrame
import com.harsh.wifigamepad.protocol.WelcomeFrame
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.SocketTimeoutException
import java.util.concurrent.atomic.AtomicLong

enum class ConnectionState { IDLE, DISCOVERING, CONNECTING, CONNECTED, REJECTED, DISCONNECTED, RECONNECTING }

data class DiscoveredTv(val name: String, val ip: String, val port: Int)

data class ConnectionStatus(
    val state: ConnectionState = ConnectionState.IDLE,
    val tvName: String? = null,
    val latencyMs: Long? = null,
    val error: String? = null
)

/**
 * All Wi-Fi networking for the phone side: LAN discovery (UDP broadcast),
 * pairing handshake, periodic ping/pong for latency + liveness, low-latency
 * UDP event sending, and automatic reconnection.
 *
 * No Bluetooth. No internet/cloud calls of any kind.
 */
class GamepadClient(
    private val controllerId: String,
    private val controllerName: String
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var socket: DatagramSocket? = null
    private var reconnectJob: Job? = null
    private var pingJob: Job? = null
    private var listenJob: Job? = null

    private var tvAddress: InetSocketAddress? = null
    private var sessionToken: String? = null
    private val seq = AtomicLong(0)
    private var autoReconnect = true
    private var pin: String = ""

    private val _status = MutableStateFlow(ConnectionStatus())
    val status: StateFlow<ConnectionStatus> = _status.asStateFlow()

    private val _discovered = MutableStateFlow<List<DiscoveredTv>>(emptyList())
    val discovered: StateFlow<List<DiscoveredTv>> = _discovered.asStateFlow()

    /** Broadcasts a discovery request and collects responses for [windowMs]. */
    fun discover(windowMs: Long = 2500) {
        scope.launch {
            _status.value = _status.value.copy(state = ConnectionState.DISCOVERING, error = null)
            _discovered.value = emptyList()
            val found = LinkedHashMap<String, DiscoveredTv>()
            try {
                DatagramSocket().use { ds ->
                    ds.broadcast = true
                    ds.soTimeout = 300
                    val req = DiscoveryRequest().encode().toByteArray()
                    val broadcastAddr = InetAddress.getByName("255.255.255.255")
                    val packet = DatagramPacket(req, req.size, broadcastAddr, ProtocolConstants.DISCOVERY_PORT)

                    val deadline = System.currentTimeMillis() + windowMs
                    while (System.currentTimeMillis() < deadline) {
                        ds.send(packet)
                        try {
                            val buf = ByteArray(512)
                            val resp = DatagramPacket(buf, buf.size)
                            ds.receive(resp)
                            val text = String(resp.data, 0, resp.length)
                            val dr = DiscoveryResponse.decode(text)
                            val ip = resp.address.hostAddress
                            if (dr != null && ip != null) {
                                found[ip] = DiscoveredTv(dr.tvName, ip, dr.gamePort)
                                _discovered.value = found.values.toList()
                            }
                        } catch (_: SocketTimeoutException) {
                            // no response yet, keep broadcasting until window closes
                        }
                    }
                }
            } catch (e: Exception) {
                _status.value = _status.value.copy(error = "Discovery failed: ${e.message}")
            }
            if (_status.value.state == ConnectionState.DISCOVERING) {
                _status.value = _status.value.copy(state = ConnectionState.IDLE)
            }
        }
    }

    /** Connects (or reconnects) to a TV at [ip]:[port] using the given pairing [pin]. */
    fun connect(ip: String, port: Int, pin: String, autoReconnect: Boolean) {
        this.autoReconnect = autoReconnect
        this.pin = pin
        tvAddress = InetSocketAddress(ip, port)
        scope.launch { doHandshake() }
    }

    private suspend fun doHandshake() {
        val addr = tvAddress ?: return
        _status.value = _status.value.copy(state = ConnectionState.CONNECTING, error = null)
        closeSocketOnly()
        val ds = DatagramSocket().apply { soTimeout = 2000 }
        socket = ds

        val hello = HelloFrame(controllerId, controllerName, pin).encode().toByteArray()
        val helloPacket = DatagramPacket(hello, hello.size, addr.address, addr.port)

        var attempts = 0
        var welcomed: WelcomeFrame? = null
        var rejected: RejectFrame? = null
        while (attempts < 5 && welcomed == null && rejected == null) {
            try {
                ds.send(helloPacket)
                val buf = ByteArray(512)
                val resp = DatagramPacket(buf, buf.size)
                ds.receive(resp)
                val text = String(resp.data, 0, resp.length)
                welcomed = WelcomeFrame.decode(text)
                if (welcomed == null) rejected = RejectFrame.decode(text)
            } catch (_: SocketTimeoutException) {
                attempts++
            }
        }

        when {
            welcomed != null -> {
                sessionToken = welcomed.sessionToken
                _status.value = ConnectionStatus(state = ConnectionState.CONNECTED, tvName = null)
                startListening()
                startPingLoop()
            }
            rejected != null -> {
                _status.value = ConnectionStatus(state = ConnectionState.REJECTED, error = rejected.reason)
            }
            else -> {
                _status.value = ConnectionStatus(state = ConnectionState.DISCONNECTED, error = "TV did not respond")
                if (autoReconnect) scheduleReconnect()
            }
        }
    }

    private fun startListening() {
        listenJob?.cancel()
        listenJob = scope.launch {
            val ds = socket ?: return@launch
            ds.soTimeout = 4000
            while (true) {
                try {
                    val buf = ByteArray(512)
                    val packet = DatagramPacket(buf, buf.size)
                    ds.receive(packet)
                    val text = String(packet.data, 0, packet.length)
                    PongFrame.decode(text)?.let { pong ->
                        val rtt = System.currentTimeMillis() - pong.clientTimeMillis
                        _status.value = _status.value.copy(latencyMs = rtt)
                    }
                } catch (_: SocketTimeoutException) {
                    // TV went quiet -> treat as disconnect, try to reconnect
                    if (_status.value.state == ConnectionState.CONNECTED) {
                        _status.value = _status.value.copy(state = ConnectionState.DISCONNECTED, error = "Connection lost")
                        if (autoReconnect) scheduleReconnect()
                    }
                    break
                } catch (e: Exception) {
                    break
                }
            }
        }
    }

    private fun startPingLoop() {
        pingJob?.cancel()
        pingJob = scope.launch {
            while (_status.value.state == ConnectionState.CONNECTED) {
                sendRaw(PingFrame(System.currentTimeMillis()).encode())
                delay(1500)
            }
        }
    }

    private fun scheduleReconnect() {
        reconnectJob?.cancel()
        reconnectJob = scope.launch {
            var backoffMs = 1000L
            while (_status.value.state != ConnectionState.CONNECTED) {
                _status.value = _status.value.copy(state = ConnectionState.RECONNECTING)
                delay(backoffMs)
                doHandshake()
                backoffMs = (backoffMs * 2).coerceAtMost(10_000)
                if (_status.value.state == ConnectionState.CONNECTED) break
            }
        }
    }

    /** Sends a single gamepad event (button or joystick) with the active session token. */
    fun sendEvent(event: GamepadEvent) {
        if (_status.value.state != ConnectionState.CONNECTED) return
        val token = sessionToken ?: return
        val frame = InputFrame(token, seq.incrementAndGet(), event)
        sendRaw(frame.encode())
    }

    private fun sendRaw(text: String) {
        val addr = tvAddress ?: return
        val ds = socket ?: return
        try {
            val bytes = text.toByteArray()
            ds.send(DatagramPacket(bytes, bytes.size, addr.address, addr.port))
        } catch (_: Exception) {
            // Best-effort for UDP; dropped packets are expected occasionally.
        }
    }

    fun disconnect() {
        reconnectJob?.cancel()
        pingJob?.cancel()
        val token = sessionToken
        if (token != null) sendRaw(ByeFrame(token).encode())
        listenJob?.cancel()
        closeSocketOnly()
        sessionToken = null
        _status.value = ConnectionStatus(state = ConnectionState.IDLE)
    }

    private fun closeSocketOnly() {
        try { socket?.close() } catch (_: Exception) {}
        socket = null
    }
}
