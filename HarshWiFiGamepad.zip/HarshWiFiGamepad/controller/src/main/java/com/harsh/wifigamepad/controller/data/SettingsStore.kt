package com.harsh.wifigamepad.controller.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.util.UUID

private val Context.dataStore by preferencesDataStore(name = "harsh_gamepad_settings")

/**
 * Persists everything the "Settings" screen exposes:
 *  - controller name / stable controller id
 *  - button size + joystick sensitivity
 *  - vibration on/off
 *  - last connected TV (ip/port) + auto-reconnect toggle
 *  - theme accent
 */
class SettingsStore(private val context: Context) {

    private object Keys {
        val CONTROLLER_ID = stringPreferencesKey("controller_id")
        val CONTROLLER_NAME = stringPreferencesKey("controller_name")
        val BUTTON_SIZE = floatPreferencesKey("button_size")          // scale 0.7f..1.4f
        val STICK_SENSITIVITY = floatPreferencesKey("stick_sensitivity") // scale 0.5f..2.0f
        val VIBRATION_ENABLED = booleanPreferencesKey("vibration_enabled")
        val AUTO_RECONNECT = booleanPreferencesKey("auto_reconnect")
        val LAST_TV_IP = stringPreferencesKey("last_tv_ip")
        val LAST_TV_PORT = intPreferencesKey("last_tv_port")
        val ACCENT = stringPreferencesKey("accent") // "cyan" | "magenta" | "green"
        val LAYOUT_MODE = stringPreferencesKey("layout_mode") // "default" | "southpaw"
    }

    val controllerName: Flow<String> = context.dataStore.data.map { it[Keys.CONTROLLER_NAME] ?: "HARSH PHONE" }
    val buttonSize: Flow<Float> = context.dataStore.data.map { it[Keys.BUTTON_SIZE] ?: 1.0f }
    val stickSensitivity: Flow<Float> = context.dataStore.data.map { it[Keys.STICK_SENSITIVITY] ?: 1.0f }
    val vibrationEnabled: Flow<Boolean> = context.dataStore.data.map { it[Keys.VIBRATION_ENABLED] ?: true }
    val autoReconnect: Flow<Boolean> = context.dataStore.data.map { it[Keys.AUTO_RECONNECT] ?: true }
    val lastTvIp: Flow<String?> = context.dataStore.data.map { it[Keys.LAST_TV_IP] }
    val lastTvPort: Flow<Int?> = context.dataStore.data.map { it[Keys.LAST_TV_PORT] }
    val accent: Flow<String> = context.dataStore.data.map { it[Keys.ACCENT] ?: "cyan" }
    val layoutMode: Flow<String> = context.dataStore.data.map { it[Keys.LAYOUT_MODE] ?: "default" }

    /** Returns a stable per-install controller id, generating and persisting one on first use. */
    suspend fun getOrCreateControllerId(): String {
        var id: String? = null
        context.dataStore.edit { prefs ->
            if (prefs[Keys.CONTROLLER_ID] == null) {
                prefs[Keys.CONTROLLER_ID] = UUID.randomUUID().toString()
            }
            id = prefs[Keys.CONTROLLER_ID]
        }
        return id ?: UUID.randomUUID().toString()
    }

    suspend fun setControllerName(name: String) = context.dataStore.edit { it[Keys.CONTROLLER_NAME] = name }
    suspend fun setButtonSize(scale: Float) = context.dataStore.edit { it[Keys.BUTTON_SIZE] = scale }
    suspend fun setStickSensitivity(scale: Float) = context.dataStore.edit { it[Keys.STICK_SENSITIVITY] = scale }
    suspend fun setVibrationEnabled(enabled: Boolean) = context.dataStore.edit { it[Keys.VIBRATION_ENABLED] = enabled }
    suspend fun setAutoReconnect(enabled: Boolean) = context.dataStore.edit { it[Keys.AUTO_RECONNECT] = enabled }
    suspend fun setAccent(accent: String) = context.dataStore.edit { it[Keys.ACCENT] = accent }
    suspend fun setLayoutMode(mode: String) = context.dataStore.edit { it[Keys.LAYOUT_MODE] = mode }
    suspend fun setLastTv(ip: String, port: Int) = context.dataStore.edit {
        it[Keys.LAST_TV_IP] = ip
        it[Keys.LAST_TV_PORT] = port
    }
}
