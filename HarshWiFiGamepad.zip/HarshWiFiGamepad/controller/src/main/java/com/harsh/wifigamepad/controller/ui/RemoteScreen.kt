package com.harsh.wifigamepad.controller.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.FastRewind
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowLeft
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.VolumeDown
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.harsh.wifigamepad.controller.network.ConnectionState
import com.harsh.wifigamepad.controller.ui.components.GlassButton
import com.harsh.wifigamepad.controller.ui.components.GlassChip
import com.harsh.wifigamepad.controller.ui.components.ModeSwitch
import com.harsh.wifigamepad.controller.ui.components.PillShape
import com.harsh.wifigamepad.controller.ui.components.StatusPill
import com.harsh.wifigamepad.controller.ui.components.liquidGlass
import com.harsh.wifigamepad.controller.ui.theme.LocalAccent
import com.harsh.wifigamepad.controller.viewmodel.ControllerUiState
import com.harsh.wifigamepad.protocol.ButtonCode

/** TV remote mode (portrait). */
@Composable
fun RemoteScreen(
    state: ControllerUiState,
    onButtonDown: (ButtonCode) -> Unit,
    onButtonUp: (ButtonCode) -> Unit,
    onSwitchMode: () -> Unit,
    onOpenSettings: () -> Unit,
    onDisconnect: () -> Unit
) {
    val accent = LocalAccent.current
    val connected = state.connection.state == ConnectionState.CONNECTED

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp, vertical = 14.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Top bar
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            StatusPill(connected, state.connectionLabel())
            ModeSwitch(remoteSelected = true, onRemote = {}, onGamepad = onSwitchMode)
        }

        // Back / Home / Apps
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            LabeledPill(Icons.Filled.ArrowBack, "Back", ButtonCode.BACK, onButtonDown, onButtonUp, Modifier.weight(1f))
            LabeledPill(Icons.Filled.Home, "Home", ButtonCode.HOME, onButtonDown, onButtonUp, Modifier.weight(1f))
            LabeledPill(Icons.Filled.Apps, "Apps", ButtonCode.SELECT, onButtonDown, onButtonUp, Modifier.weight(1f))
        }

        // D-pad ring with OK
        Box(Modifier.size(232.dp), contentAlignment = Alignment.Center) {
            Box(Modifier.fillMaxSize().liquidGlass(CircleShape, elevation = 16.dp))
            RoundKey(Icons.Filled.KeyboardArrowUp, ButtonCode.DPAD_UP, onButtonDown, onButtonUp, Modifier.align(Alignment.TopCenter).padding(top = 8.dp).size(64.dp))
            RoundKey(Icons.Filled.KeyboardArrowDown, ButtonCode.DPAD_DOWN, onButtonDown, onButtonUp, Modifier.align(Alignment.BottomCenter).padding(bottom = 8.dp).size(64.dp))
            RoundKey(Icons.Filled.KeyboardArrowLeft, ButtonCode.DPAD_LEFT, onButtonDown, onButtonUp, Modifier.align(Alignment.CenterStart).padding(start = 8.dp).size(64.dp))
            RoundKey(Icons.Filled.KeyboardArrowRight, ButtonCode.DPAD_RIGHT, onButtonDown, onButtonUp, Modifier.align(Alignment.CenterEnd).padding(end = 8.dp).size(64.dp))
            GlassButton(
                shape = CircleShape,
                modifier = Modifier.size(86.dp),
                tint = accent,
                onDown = { onButtonDown(ButtonCode.A) },
                onUp = { onButtonUp(ButtonCode.A) }
            ) {
                Text("OK", color = Color.White, fontWeight = FontWeight.Black, fontSize = 22.sp)
            }
        }

        // Volume
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            IconPill(Icons.Filled.VolumeDown, ButtonCode.VOL_DOWN, onButtonDown, onButtonUp, Modifier.weight(1f))
            IconPill(Icons.Filled.VolumeOff, ButtonCode.MUTE, onButtonDown, onButtonUp, Modifier.weight(1f))
            IconPill(Icons.Filled.VolumeUp, ButtonCode.VOL_UP, onButtonDown, onButtonUp, Modifier.weight(1f))
        }

        // Media bar
        Box(
            Modifier
                .fillMaxWidth()
                .height(72.dp)
                .liquidGlass(PillShape, elevation = 8.dp),
            contentAlignment = Alignment.Center
        ) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 10.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                RoundKey(Icons.Filled.SkipPrevious, ButtonCode.PREV, onButtonDown, onButtonUp, Modifier.size(46.dp))
                RoundKey(Icons.Filled.FastRewind, ButtonCode.REWIND, onButtonDown, onButtonUp, Modifier.size(46.dp))
                RoundKey(Icons.Filled.PlayArrow, ButtonCode.PLAY_PAUSE, onButtonDown, onButtonUp, Modifier.size(58.dp), tint = accent)
                RoundKey(Icons.Filled.FastForward, ButtonCode.FORWARD, onButtonDown, onButtonUp, Modifier.size(46.dp))
                RoundKey(Icons.Filled.SkipNext, ButtonCode.NEXT, onButtonDown, onButtonUp, Modifier.size(46.dp))
            }
        }

        // Bottom actions
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            GlassChip("SETTINGS", onOpenSettings)
            if (connected) GlassChip("DISCONNECT", onDisconnect)
        }
    }
}

@Composable
private fun LabeledPill(
    icon: ImageVector,
    label: String,
    code: ButtonCode,
    onDown: (ButtonCode) -> Unit,
    onUp: (ButtonCode) -> Unit,
    modifier: Modifier = Modifier
) {
    GlassButton(
        shape = PillShape,
        modifier = modifier.height(52.dp),
        onDown = { onDown(code) },
        onUp = { onUp(code) }
    ) {
        Icon(icon, contentDescription = label, tint = Color.White, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(6.dp))
        Text(label, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
    }
}

@Composable
private fun IconPill(
    icon: ImageVector,
    code: ButtonCode,
    onDown: (ButtonCode) -> Unit,
    onUp: (ButtonCode) -> Unit,
    modifier: Modifier = Modifier
) {
    GlassButton(
        shape = PillShape,
        modifier = modifier.height(56.dp),
        onDown = { onDown(code) },
        onUp = { onUp(code) }
    ) {
        Icon(icon, contentDescription = code.name, tint = Color.White)
    }
}

@Composable
private fun RoundKey(
    icon: ImageVector,
    code: ButtonCode,
    onDown: (ButtonCode) -> Unit,
    onUp: (ButtonCode) -> Unit,
    modifier: Modifier = Modifier,
    shape: Shape = CircleShape,
    tint: Color = Color.White
) {
    GlassButton(
        shape = shape,
        modifier = modifier,
        tint = tint,
        onDown = { onDown(code) },
        onUp = { onUp(code) }
    ) {
        Icon(icon, contentDescription = code.name, tint = Color.White)
    }
}
