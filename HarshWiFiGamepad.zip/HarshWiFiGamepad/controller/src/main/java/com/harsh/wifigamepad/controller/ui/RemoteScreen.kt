package com.harsh.wifigamepad.controller.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.FastRewind
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowLeft
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.VolumeDown
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.harsh.wifigamepad.controller.network.ConnectionState
import com.harsh.wifigamepad.controller.ui.components.GlassButton
import com.harsh.wifigamepad.controller.ui.components.GlassChip
import com.harsh.wifigamepad.controller.ui.components.liquidGlass
import com.harsh.wifigamepad.controller.ui.theme.HarshAccent
import com.harsh.wifigamepad.controller.ui.theme.HarshMuted
import com.harsh.wifigamepad.controller.ui.theme.HarshSuccess
import com.harsh.wifigamepad.controller.viewmodel.ControllerUiState
import com.harsh.wifigamepad.protocol.ButtonCode

/** TV remote mode. The app forces portrait while this screen is showing. */
@Composable
fun RemoteScreen(
    state: ControllerUiState,
    onButtonDown: (ButtonCode) -> Unit,
    onButtonUp: (ButtonCode) -> Unit,
    onSwitchMode: () -> Unit,
    onOpenSettings: () -> Unit,
    onDisconnect: () -> Unit
) {
    val connected = state.connection.state == ConnectionState.CONNECTED
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp, vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceEvenly
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column {
                Text("HARSH REMOTE", color = HarshAccent, fontWeight = FontWeight.Black, fontSize = 16.sp)
                Text(
                    text = if (connected) "Connected${state.connection.latencyMs?.let { " · ${it}ms" } ?: ""}"
                    else state.connection.state.name.lowercase().replaceFirstChar { it.uppercase() },
                    color = if (connected) HarshSuccess else HarshMuted,
                    fontSize = 11.sp
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                GlassChip("GAMEPAD", onSwitchMode)
                GlassChip("SETTINGS", onOpenSettings)
                if (connected) GlassChip("EXIT", onDisconnect)
            }
        }

        // Back / Home / Apps
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            RemoteKey(Icons.Filled.ArrowBack, ButtonCode.BACK, onButtonDown, onButtonUp, Modifier.size(88.dp, 54.dp), RoundedCornerShape(27.dp))
            RemoteKey(Icons.Filled.Home, ButtonCode.HOME, onButtonDown, onButtonUp, Modifier.size(88.dp, 54.dp), RoundedCornerShape(27.dp))
            RemoteKey(Icons.Filled.Apps, ButtonCode.SELECT, onButtonDown, onButtonUp, Modifier.size(88.dp, 54.dp), RoundedCornerShape(27.dp))
        }

        // D-pad ring with OK in the middle
        Box(Modifier.size(250.dp), contentAlignment = Alignment.Center) {
            Box(Modifier.fillMaxSize().liquidGlass(CircleShape, elevation = 16.dp))
            RemoteKey(Icons.Filled.KeyboardArrowUp, ButtonCode.DPAD_UP, onButtonDown, onButtonUp, Modifier.align(Alignment.TopCenter).padding(top = 10.dp).size(70.dp))
            RemoteKey(Icons.Filled.KeyboardArrowDown, ButtonCode.DPAD_DOWN, onButtonDown, onButtonUp, Modifier.align(Alignment.BottomCenter).padding(bottom = 10.dp).size(70.dp))
            RemoteKey(Icons.Filled.KeyboardArrowLeft, ButtonCode.DPAD_LEFT, onButtonDown, onButtonUp, Modifier.align(Alignment.CenterStart).padding(start = 10.dp).size(70.dp))
            RemoteKey(Icons.Filled.KeyboardArrowRight, ButtonCode.DPAD_RIGHT, onButtonDown, onButtonUp, Modifier.align(Alignment.CenterEnd).padding(end = 10.dp).size(70.dp))
            GlassButton(
                shape = CircleShape,
                modifier = Modifier.size(92.dp),
                tint = HarshAccent,
                onDown = { onButtonDown(ButtonCode.A) },
                onUp = { onButtonUp(ButtonCode.A) }
            ) {
                Text("OK", color = Color.White, fontWeight = FontWeight.Black, fontSize = 22.sp)
            }
        }

        // Volume
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            RemoteKey(Icons.Filled.VolumeDown, ButtonCode.VOL_DOWN, onButtonDown, onButtonUp, Modifier.size(88.dp, 58.dp), RoundedCornerShape(29.dp))
            RemoteKey(Icons.Filled.VolumeOff, ButtonCode.MUTE, onButtonDown, onButtonUp, Modifier.size(88.dp, 58.dp), RoundedCornerShape(29.dp))
            RemoteKey(Icons.Filled.VolumeUp, ButtonCode.VOL_UP, onButtonDown, onButtonUp, Modifier.size(88.dp, 58.dp), RoundedCornerShape(29.dp))
        }

        // Media
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
            RemoteKey(Icons.Filled.SkipPrevious, ButtonCode.PREV, onButtonDown, onButtonUp, Modifier.size(52.dp))
            RemoteKey(Icons.Filled.FastRewind, ButtonCode.REWIND, onButtonDown, onButtonUp, Modifier.size(52.dp))
            RemoteKey(Icons.Filled.PlayArrow, ButtonCode.PLAY_PAUSE, onButtonDown, onButtonUp, Modifier.size(68.dp), tint = HarshAccent)
            RemoteKey(Icons.Filled.FastForward, ButtonCode.FORWARD, onButtonDown, onButtonUp, Modifier.size(52.dp))
            RemoteKey(Icons.Filled.SkipNext, ButtonCode.NEXT, onButtonDown, onButtonUp, Modifier.size(52.dp))
        }
    }
}

@Composable
private fun RemoteKey(
    icon: ImageVector,
    code: ButtonCode,
    onDown: (ButtonCode) -> Unit,
    onUp: (ButtonCode) -> Unit,
    modifier: Modifier = Modifier,
    shape: Shape = CircleShape,
    tint: Color = Color.White
) {
    GlassButton(
        shape = shape,
        modifier = modifier,
        tint = tint,
        onDown = { onDown(code) },
        onUp = { onUp(code) }
    ) {
        Icon(icon, contentDescription = code.name, tint = Color.White)
    }
}
