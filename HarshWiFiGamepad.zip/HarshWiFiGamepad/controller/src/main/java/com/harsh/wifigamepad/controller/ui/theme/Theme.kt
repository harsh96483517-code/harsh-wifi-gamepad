package com.harsh.wifigamepad.controller.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val HarshColorScheme = darkColorScheme(
    background = HarshBackground,
    surface = HarshSurface,
    primary = HarshAccent,
    secondary = HarshAccentAlt,
    onBackground = HarshOnBackground,
    onSurface = HarshOnBackground,
    error = HarshDanger
)

@Composable
fun HarshWiFiGamepadTheme(content: @Composable () -> Unit) {
    // Always dark: this is a dedicated black gaming UI regardless of system theme.
    MaterialTheme(
        colorScheme = HarshColorScheme,
        typography = HarshTypography,
        content = content
    )
}
