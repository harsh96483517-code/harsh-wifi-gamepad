package com.harsh.wifigamepad.controller.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.graphics.Color

/** Current accent colour (user-selectable in Settings). */
val LocalAccent = compositionLocalOf { HarshAccent }

fun accentFor(key: String): Color = when (key) {
    "magenta" -> Color(0xFFFF2D78)
    "green" -> Color(0xFF34D399)
    else -> HarshAccent
}

@Composable
fun HarshWiFiGamepadTheme(accent: Color = HarshAccent, content: @Composable () -> Unit) {
    val scheme = darkColorScheme(
        background = HarshBackground,
        surface = HarshSurface,
        primary = accent,
        secondary = HarshAccentAlt,
        onBackground = HarshOnBackground,
        onSurface = HarshOnBackground,
        error = HarshDanger
    )
    CompositionLocalProvider(LocalAccent provides accent) {
        MaterialTheme(colorScheme = scheme, typography = HarshTypography, content = content)
    }
}
