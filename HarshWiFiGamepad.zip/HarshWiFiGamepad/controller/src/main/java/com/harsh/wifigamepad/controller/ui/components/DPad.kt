package com.harsh.wifigamepad.controller.ui.components

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowLeft
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.harsh.wifigamepad.protocol.ButtonCode

@Composable
fun DPad(
    sizeDp: Dp = 132.dp,
    onDown: (ButtonCode) -> Unit,
    onUp: (ButtonCode) -> Unit,
    modifier: Modifier = Modifier
) {
    val cell = sizeDp / 3
    Column(modifier = modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        DPadKey(cell, Icons.Filled.KeyboardArrowUp, ButtonCode.DPAD_UP, onDown, onUp)
        Row {
            DPadKey(cell, Icons.Filled.KeyboardArrowLeft, ButtonCode.DPAD_LEFT, onDown, onUp)
            Box(Modifier.size(cell))
            DPadKey(cell, Icons.Filled.KeyboardArrowRight, ButtonCode.DPAD_RIGHT, onDown, onUp)
        }
        DPadKey(cell, Icons.Filled.KeyboardArrowDown, ButtonCode.DPAD_DOWN, onDown, onUp)
    }
}

@Composable
private fun DPadKey(
    size: Dp,
    icon: ImageVector,
    code: ButtonCode,
    onDown: (ButtonCode) -> Unit,
    onUp: (ButtonCode) -> Unit
) {
    GlassButton(
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.size(size),
        onDown = { onDown(code) },
        onUp = { onUp(code) }
    ) {
        Icon(icon, contentDescription = code.name, tint = Color.White)
    }
}
