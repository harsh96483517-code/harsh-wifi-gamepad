package com.harsh.wifigamepad.controller.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.waitForUpOrCancel
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowLeft
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.harsh.wifigamepad.controller.ui.theme.HarshButtonFace
import com.harsh.wifigamepad.controller.ui.theme.HarshButtonFacePressed
import com.harsh.wifigamepad.protocol.ButtonCode

@Composable
fun DPad(
    sizeDp: Dp = 132.dp,
    onDown: (ButtonCode) -> Unit,
    onUp: (ButtonCode) -> Unit,
    modifier: Modifier = Modifier
) {
    val cell = sizeDp / 3
    Column(modifier = modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        DPadKey(cell, Icons.Filled.KeyboardArrowUp, ButtonCode.DPAD_UP, onDown, onUp)
        Row {
            DPadKey(cell, Icons.Filled.KeyboardArrowLeft, ButtonCode.DPAD_LEFT, onDown, onUp)
            Box(Modifier.size(cell))
            DPadKey(cell, Icons.Filled.KeyboardArrowRight, ButtonCode.DPAD_RIGHT, onDown, onUp)
        }
        DPadKey(cell, Icons.Filled.KeyboardArrowDown, ButtonCode.DPAD_DOWN, onDown, onUp)
    }
}

@Composable
private fun DPadKey(
    size: Dp,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    code: ButtonCode,
    onDown: (ButtonCode) -> Unit,
    onUp: (ButtonCode) -> Unit
) {
    var pressed by remember { mutableStateOf(false) }
    Box(
        modifier = Modifier
            .size(size)
            .background(if (pressed) HarshButtonFacePressed else HarshButtonFace, RoundedCornerShape(6.dp))
            .pointerInput(code) {
                awaitPointerEventScope {
                    while (true) {
                        awaitFirstDown()
                        pressed = true
                        onDown(code)
                        waitForUpOrCancel()
                        pressed = false
                        onUp(code)
                    }
                }
            },
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, contentDescription = code.name, tint = Color(0xFFCFCFE0))
    }
}
