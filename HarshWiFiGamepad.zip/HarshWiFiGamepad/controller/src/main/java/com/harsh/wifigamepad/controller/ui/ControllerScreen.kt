package com.harsh.wifigamepad.controller.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.harsh.wifigamepad.controller.network.ConnectionState
import com.harsh.wifigamepad.controller.ui.components.ActionButton
import com.harsh.wifigamepad.controller.ui.components.DPad
import com.harsh.wifigamepad.controller.ui.components.GlassChip
import com.harsh.wifigamepad.controller.ui.components.Joystick
import com.harsh.wifigamepad.controller.ui.components.ModeSwitch
import com.harsh.wifigamepad.controller.ui.components.RectButton
import com.harsh.wifigamepad.controller.ui.components.StatusPill
import com.harsh.wifigamepad.controller.ui.theme.HarshAccentAlt
import com.harsh.wifigamepad.controller.ui.theme.LocalAccent
import com.harsh.wifigamepad.controller.viewmodel.ControllerUiState
import com.harsh.wifigamepad.protocol.ButtonCode

/** Gamepad mode (landscape). */
@Composable
fun ControllerScreen(
    state: ControllerUiState,
    onButtonDown: (ButtonCode) -> Unit,
    onButtonUp: (ButtonCode) -> Unit,
    onLeftStick: (Float, Float) -> Unit,
    onRightStick: (Float, Float) -> Unit,
    onOpenSettings: () -> Unit,
    onDisconnect: () -> Unit,
    onSwitchMode: () -> Unit
) {
    val accent = LocalAccent.current
    val cfg = LocalConfiguration.current
    val h = minOf(cfg.screenHeightDp, cfg.screenWidthDp).toFloat()
    val scale = state.buttonSize
    // top bar + shoulder row + paddings ~ 132dp; two items are stacked per side
    val itemMax = ((h - 132f) - 12f) / 2f
    val stickSize = minOf(110f * scale, itemMax).dp
    val dpadSize = minOf(120f * scale, itemMax).dp
    val faceBtn = (minOf(174f * scale, itemMax) / 3f).dp
    val connected = state.connection.state == ConnectionState.CONNECTED

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(12.dp)
    ) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            StatusPill(connected, state.connectionLabel())
            ModeSwitch(remoteSelected = false, onRemote = onSwitchMode, onGamepad = {})
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GlassChip("SETTINGS", onOpenSettings)
                if (connected) GlassChip("DISCONNECT", onDisconnect)
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                RectButton("L2", ButtonCode.L2, onButtonDown, onButtonUp, Modifier.size(76.dp, 36.dp))
                RectButton("L1", ButtonCode.L1, onButtonDown, onButtonUp, Modifier.size(76.dp, 36.dp))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                RectButton("R1", ButtonCode.R1, onButtonDown, onButtonUp, Modifier.size(76.dp, 36.dp))
                RectButton("R2", ButtonCode.R2, onButtonDown, onButtonUp, Modifier.size(76.dp, 36.dp))
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(
            modifier = Modifier.fillMaxSize(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                DPad(sizeDp = dpadSize, onDown = onButtonDown, onUp = onButtonUp)
                Joystick(sizeDp = stickSize, onMove = onLeftStick)
            }

            // System buttons in the middle
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    RectButton("SELECT", ButtonCode.SELECT, onButtonDown, onButtonUp, Modifier.size(84.dp, 36.dp))
                    RectButton("START", ButtonCode.START, onButtonDown, onButtonUp, Modifier.size(84.dp, 36.dp))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    RectButton("BACK", ButtonCode.BACK, onButtonDown, onButtonUp, Modifier.size(84.dp, 36.dp))
                    RectButton("HOME", ButtonCode.HOME, onButtonDown, onButtonUp, Modifier.size(84.dp, 36.dp))
                }
            }

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                FaceButtonCluster(faceBtn, accent, onButtonDown, onButtonUp)
                Joystick(sizeDp = stickSize, onMove = onRightStick)
            }
        }
    }
}

@Composable
private fun FaceButtonCluster(
    size: Dp,
    accent: androidx.compose.ui.graphics.Color,
    onDown: (ButtonCode) -> Unit,
    onUp: (ButtonCode) -> Unit
) {
    Box(modifier = Modifier.size(size * 3)) {
        ActionButton("Y", ButtonCode.Y, size, HarshAccentAlt, onDown, onUp, modifier = Modifier.align(Alignment.TopCenter))
        ActionButton("X", ButtonCode.X, size, accent, onDown, onUp, modifier = Modifier.align(Alignment.CenterStart))
        ActionButton("B", ButtonCode.B, size, HarshAccentAlt, onDown, onUp, modifier = Modifier.align(Alignment.CenterEnd))
        ActionButton("A", ButtonCode.A, size, accent, onDown, onUp, modifier = Modifier.align(Alignment.BottomCenter))
    }
}
