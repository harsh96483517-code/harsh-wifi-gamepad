package com.harsh.wifigamepad.controller.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.harsh.wifigamepad.controller.network.ConnectionState
import com.harsh.wifigamepad.controller.ui.components.ActionButton
import com.harsh.wifigamepad.controller.ui.components.DPad
import com.harsh.wifigamepad.controller.ui.components.Joystick
import com.harsh.wifigamepad.controller.ui.components.RectButton
import com.harsh.wifigamepad.controller.ui.theme.HarshAccent
import com.harsh.wifigamepad.controller.ui.theme.HarshAccentAlt
import com.harsh.wifigamepad.controller.ui.theme.HarshBackground
import com.harsh.wifigamepad.controller.ui.theme.HarshMuted
import com.harsh.wifigamepad.controller.ui.theme.HarshSuccess
import com.harsh.wifigamepad.controller.viewmodel.ControllerUiState
import com.harsh.wifigamepad.protocol.ButtonCode

@Composable
fun ControllerScreen(
    state: ControllerUiState,
    onButtonDown: (ButtonCode) -> Unit,
    onButtonUp: (ButtonCode) -> Unit,
    onLeftStick: (Float, Float) -> Unit,
    onRightStick: (Float, Float) -> Unit,
    onOpenSettings: () -> Unit,
    onDisconnect: () -> Unit
) {
    val isLandscape = LocalConfiguration.current.screenWidthDp > LocalConfiguration.current.screenHeightDp
    val scale = state.buttonSize
    val stickSize = (110 * scale).dp
    val dpadSize = (120 * scale).dp
    val faceButtonSize = (58 * scale).dp

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(HarshBackground)
            .padding(12.dp)
    ) {
        TopStatusBar(state, onOpenSettings, onDisconnect)
        Spacer(Modifier.height(8.dp))

        if (isLandscape) {
            Row(
                modifier = Modifier.fillMaxSize(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Joystick(sizeDp = stickSize, onMove = onLeftStick)
                    Spacer(Modifier.height(18.dp))
                    DPad(sizeDp = dpadSize, onDown = onButtonDown, onUp = onButtonUp)
                }

                CenterButtons(onButtonDown, onButtonUp)

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    FaceButtonCluster(faceButtonSize, onButtonDown, onButtonUp)
                    Spacer(Modifier.height(18.dp))
                    Joystick(sizeDp = stickSize, onMove = onRightStick)
                }
            }
        } else {
            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    RectButton("L1", ButtonCode.L1, onButtonDown, onButtonUp, Modifier.size(64.dp, 36.dp))
                    RectButton("R1", ButtonCode.R1, onButtonDown, onButtonUp, Modifier.size(64.dp, 36.dp))
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    RectButton("L2", ButtonCode.L2, onButtonDown, onButtonUp, Modifier.size(64.dp, 36.dp))
                    RectButton("R2", ButtonCode.R2, onButtonDown, onButtonUp, Modifier.size(64.dp, 36.dp))
                }
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    DPad(sizeDp = dpadSize, onDown = onButtonDown, onUp = onButtonUp)
                    FaceButtonCluster(faceButtonSize, onButtonDown, onButtonUp)
                }
                CenterButtons(onButtonDown, onButtonUp)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Joystick(sizeDp = stickSize, onMove = onLeftStick)
                    Joystick(sizeDp = stickSize, onMove = onRightStick)
                }
            }
        }
    }
}

@Composable
private fun FaceButtonCluster(
    size: androidx.compose.ui.unit.Dp,
    onDown: (ButtonCode) -> Unit,
    onUp: (ButtonCode) -> Unit
) {
    // Classic diamond: Y top, X left, B right, A bottom
    Box(modifier = Modifier.size(size * 3)) {
        ActionButton("Y", ButtonCode.Y, size, HarshAccentAlt, onDown, onUp,
            modifier = Modifier.align(Alignment.TopCenter))
        ActionButton("X", ButtonCode.X, size, HarshAccent, onDown, onUp,
            modifier = Modifier.align(Alignment.CenterStart))
        ActionButton("B", ButtonCode.B, size, HarshAccentAlt, onDown, onUp,
            modifier = Modifier.align(Alignment.CenterEnd))
        ActionButton("A", ButtonCode.A, size, HarshAccent, onDown, onUp,
            modifier = Modifier.align(Alignment.BottomCenter))
    }
}

@Composable
private fun CenterButtons(onDown: (ButtonCode) -> Unit, onUp: (ButtonCode) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
        RectButton("SELECT", ButtonCode.SELECT, onDown, onUp, Modifier.size(72.dp, 32.dp))
        RectButton("HOME", ButtonCode.HOME, onDown, onUp, Modifier.size(56.dp, 32.dp))
        RectButton("START", ButtonCode.START, onDown, onUp, Modifier.size(72.dp, 32.dp))
        RectButton("BACK", ButtonCode.BACK, onDown, onUp, Modifier.size(56.dp, 32.dp))
    }
}

@Composable
private fun TopStatusBar(state: ControllerUiState, onOpenSettings: () -> Unit, onDisconnect: () -> Unit) {
    val connected = state.connection.state == ConnectionState.CONNECTED
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text("HARSH", color = HarshAccent, fontWeight = FontWeight.Black, fontSize = 16.sp)
            Text(
                text = if (connected) {
                    "Connected${state.connection.latencyMs?.let { " · ${it}ms" } ?: ""}"
                } else {
                    state.connection.state.name.lowercase().replaceFirstChar { it.uppercase() }
                },
                color = if (connected) HarshSuccess else HarshMuted,
                fontSize = 11.sp
            )
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (connected) {
                IconButton(onClick = onDisconnect) {
                    Icon(Icons.Filled.Home, contentDescription = "Disconnect", tint = HarshMuted)
                }
            }
            IconButton(onClick = onOpenSettings) {
                Icon(Icons.Filled.Settings, contentDescription = "Settings", tint = HarshMuted)
            }
        }
    }
}
