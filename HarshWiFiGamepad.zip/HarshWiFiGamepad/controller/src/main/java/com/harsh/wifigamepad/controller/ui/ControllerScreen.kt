package com.harsh.wifigamepad.controller.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.harsh.wifigamepad.controller.network.ConnectionState
import com.harsh.wifigamepad.controller.ui.components.ActionButton
import com.harsh.wifigamepad.controller.ui.components.DPad
import com.harsh.wifigamepad.controller.ui.components.GlassChip
import com.harsh.wifigamepad.controller.ui.components.Joystick
import com.harsh.wifigamepad.controller.ui.components.RectButton
import com.harsh.wifigamepad.controller.ui.theme.HarshAccent
import com.harsh.wifigamepad.controller.ui.theme.HarshAccentAlt
import com.harsh.wifigamepad.controller.ui.theme.HarshMuted
import com.harsh.wifigamepad.controller.ui.theme.HarshSuccess
import com.harsh.wifigamepad.controller.viewmodel.ControllerUiState
import com.harsh.wifigamepad.protocol.ButtonCode

/** Gamepad mode. The app forces landscape while this screen is showing. */
@Composable
fun ControllerScreen(
    state: ControllerUiState,
    onButtonDown: (ButtonCode) -> Unit,
    onButtonUp: (ButtonCode) -> Unit,
    onLeftStick: (Float, Float) -> Unit,
    onRightStick: (Float, Float) -> Unit,
    onOpenSettings: () -> Unit,
    onDisconnect: () -> Unit,
    onSwitchMode: () -> Unit
) {
    val cfg = LocalConfiguration.current
    val h = minOf(cfg.screenHeightDp, cfg.screenWidthDp).toFloat()
    val scale = state.buttonSize
    // status bar + shoulders + paddings take ~120dp; two items are stacked per side
    val itemMax = ((h - 120f) - 12f) / 2f
    val stickSize = minOf(110f * scale, itemMax).dp
    val dpadSize = minOf(120f * scale, itemMax).dp
    val faceBtn = (minOf(174f * scale, itemMax) / 3f).dp

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(12.dp)
    ) {
        TopStatusBar(state, onOpenSettings, onDisconnect, onSwitchMode)
        Spacer(Modifier.height(4.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                RectButton("L2", ButtonCode.L2, onButtonDown, onButtonUp, Modifier.size(64.dp, 34.dp))
                RectButton("L1", ButtonCode.L1, onButtonDown, onButtonUp, Modifier.size(64.dp, 34.dp))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                RectButton("R1", ButtonCode.R1, onButtonDown, onButtonUp, Modifier.size(64.dp, 34.dp))
                RectButton("R2", ButtonCode.R2, onButtonDown, onButtonUp, Modifier.size(64.dp, 34.dp))
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(
            modifier = Modifier.fillMaxSize(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                DPad(sizeDp = dpadSize, onDown = onButtonDown, onUp = onButtonUp)
                Joystick(sizeDp = stickSize, onMove = onLeftStick)
            }
            CenterButtons(onButtonDown, onButtonUp)
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                FaceButtonCluster(faceBtn, onButtonDown, onButtonUp)
                Joystick(sizeDp = stickSize, onMove = onRightStick)
            }
        }
    }
}

@Composable
private fun FaceButtonCluster(size: Dp, onDown: (ButtonCode) -> Unit, onUp: (ButtonCode) -> Unit) {
    Box(modifier = Modifier.size(size * 3)) {
        ActionButton("Y", ButtonCode.Y, size, HarshAccentAlt, onDown, onUp, modifier = Modifier.align(Alignment.TopCenter))
        ActionButton("X", ButtonCode.X, size, HarshAccent, onDown, onUp, modifier = Modifier.align(Alignment.CenterStart))
        ActionButton("B", ButtonCode.B, size, HarshAccentAlt, onDown, onUp, modifier = Modifier.align(Alignment.CenterEnd))
        ActionButton("A", ButtonCode.A, size, HarshAccent, onDown, onUp, modifier = Modifier.align(Alignment.BottomCenter))
    }
}

@Composable
private fun CenterButtons(onDown: (ButtonCode) -> Unit, onUp: (ButtonCode) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
        RectButton("SELECT", ButtonCode.SELECT, onDown, onUp, Modifier.size(72.dp, 32.dp))
        RectButton("HOME", ButtonCode.HOME, onDown, onUp, Modifier.size(56.dp, 32.dp))
        RectButton("START", ButtonCode.START, onDown, onUp, Modifier.size(72.dp, 32.dp))
        RectButton("BACK", ButtonCode.BACK, onDown, onUp, Modifier.size(56.dp, 32.dp))
    }
}

@Composable
private fun TopStatusBar(
    state: ControllerUiState,
    onOpenSettings: () -> Unit,
    onDisconnect: () -> Unit,
    onSwitchMode: () -> Unit
) {
    val connected = state.connection.state == ConnectionState.CONNECTED
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text("HARSH GAMEPAD", color = HarshAccent, fontWeight = FontWeight.Black, fontSize = 15.sp)
            Text(
                text = if (connected) {
                    "Connected${state.connection.latencyMs?.let { " · ${it}ms" } ?: ""}"
                } else {
                    state.connection.state.name.lowercase().replaceFirstChar { it.uppercase() }
                },
                color = if (connected) HarshSuccess else HarshMuted,
                fontSize = 11.sp
            )
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            GlassChip("REMOTE", onSwitchMode)
            if (connected) {
                IconButton(onClick = onDisconnect) {
                    Icon(Icons.Filled.Home, contentDescription = "Disconnect", tint = HarshMuted)
                }
            }
            IconButton(onClick = onOpenSettings) {
                Icon(Icons.Filled.Settings, contentDescription = "Settings", tint = HarshMuted)
            }
        }
    }
}
