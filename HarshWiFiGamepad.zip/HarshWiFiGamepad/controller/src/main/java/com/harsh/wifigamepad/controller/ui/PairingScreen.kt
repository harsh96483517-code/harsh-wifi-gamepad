package com.harsh.wifigamepad.controller.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning
import com.harsh.wifigamepad.protocol.QrPairingPayload
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.harsh.wifigamepad.controller.network.ConnectionState
import com.harsh.wifigamepad.controller.network.DiscoveredTv
import com.harsh.wifigamepad.controller.ui.components.GlassPanel
import com.harsh.wifigamepad.controller.ui.theme.HarshAccent
import com.harsh.wifigamepad.controller.ui.theme.HarshBackground
import com.harsh.wifigamepad.controller.ui.theme.HarshDanger
import com.harsh.wifigamepad.controller.ui.theme.HarshMuted
import com.harsh.wifigamepad.controller.viewmodel.ControllerUiState

@Composable
fun PairingScreen(
    state: ControllerUiState,
    onStartDiscovery: () -> Unit,
    onConnect: (DiscoveredTv, pin: String) -> Unit,
    onConnectManual: (ip: String, port: Int, pin: String) -> Unit
) {
    var pin by remember { mutableStateOf("") }
    var manualIp by remember { mutableStateOf("") }
    var manualPort by remember { mutableStateOf("47821") }
    var showManual by remember { mutableStateOf(false) }
    var scanError by remember { mutableStateOf<String?>(null) }
    val context = LocalContext.current

    LaunchedEffect(Unit) { onStartDiscovery() }

    Column(
        Modifier
            .fillMaxSize()
            .background(HarshBackground)
            .padding(20.dp)
    ) {
        Text("HARSH", color = HarshAccent, fontWeight = FontWeight.Black, fontSize = 30.sp)
        Text("WiFi GAMEPAD", color = Color(0xFFCFCFE0), fontWeight = FontWeight.Bold, fontSize = 14.sp, letterSpacing = 2.sp)
        Spacer(Modifier.height(20.dp))

        Row {
            Text(
                text = when (state.connection.state) {
                    ConnectionState.DISCOVERING -> "Searching for TVs..."
                    ConnectionState.CONNECTING -> "Connecting..."
                    ConnectionState.REJECTED -> "Connection rejected: ${state.connection.error ?: "wrong PIN"}"
                    ConnectionState.RECONNECTING -> "Reconnecting..."
                    else -> "Searching for TVs..."
                },
                color = HarshMuted, fontSize = 13.sp
            )
            if (state.connection.state == ConnectionState.DISCOVERING) {
                Spacer(Modifier.height(0.dp))
                CircularProgressIndicator(modifier = Modifier.height(14.dp), strokeWidth = 2.dp, color = HarshAccent)
            }
        }
        Spacer(Modifier.height(12.dp))

        Button(
            onClick = {
                val options = GmsBarcodeScannerOptions.Builder()
                    .setBarcodeFormats(Barcode.FORMAT_QR_CODE)
                    .build()
                GmsBarcodeScanning.getClient(context, options).startScan()
                    .addOnSuccessListener { barcode ->
                        val payload = barcode.rawValue?.let { QrPairingPayload.decode(it) }
                        if (payload != null) {
                            scanError = null
                            onConnectManual(payload.ip, payload.port, payload.pin)
                        } else {
                            scanError = "Ye HARSH TV ka QR nahi hai"
                        }
                    }
                    .addOnFailureListener { scanError = "Scan nahi ho paya: ${it.message}" }
            },
            colors = ButtonDefaults.buttonColors(containerColor = HarshAccent),
            modifier = Modifier.fillMaxWidth()
        ) { Text("SCAN TV QR CODE", color = Color.Black, fontWeight = FontWeight.Bold) }
        scanError?.let {
            Text(it, color = HarshDanger, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
        }
        Spacer(Modifier.height(12.dp))

        OutlinedTextField(
            value = pin,
            onValueChange = { if (it.length <= 6) pin = it.filter { c -> c.isDigit() } },
            label = { Text("Pairing PIN (from TV screen)") },
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = HarshAccent)
        )
        Spacer(Modifier.height(16.dp))

        LazyColumn(modifier = Modifier.weight(1f)) {
            items(state.discovered) { tv ->
                GlassPanel(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .padding(14.dp)
                            .clickable(enabled = pin.length in 4..6) { onConnect(tv, pin) },
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(tv.name.ifBlank { "HARSH TV RECEIVER" }, color = Color.White, fontWeight = FontWeight.Bold)
                            Text("${tv.ip}:${tv.port}", color = HarshMuted, fontSize = 12.sp)
                        }
                        Text("CONNECT", color = HarshAccent, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        Spacer(Modifier.height(8.dp))
        Text(
            "Enter IP manually",
            color = HarshAccent,
            fontWeight = FontWeight.Bold,
            fontSize = 13.sp,
            modifier = Modifier
                .clickable { showManual = !showManual }
                .padding(vertical = 8.dp)
        )

        if (showManual) {
            GlassPanel(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) {
                Column(Modifier.padding(14.dp)) {
                    OutlinedTextField(
                        value = manualIp,
                        onValueChange = { manualIp = it },
                        label = { Text("TV IP address") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = HarshAccent)
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = manualPort,
                        onValueChange = { manualPort = it.filter { c -> c.isDigit() } },
                        label = { Text("Port") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = HarshAccent)
                    )
                    Spacer(Modifier.height(10.dp))
                    Button(
                        onClick = {
                            val port = manualPort.toIntOrNull() ?: 47821
                            if (manualIp.isNotBlank() && pin.length in 4..6) onConnectManual(manualIp, port, pin)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = HarshAccent),
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Connect", color = Color.Black, fontWeight = FontWeight.Bold) }
                }
            }
        }

        if (state.connection.state == ConnectionState.REJECTED) {
            Spacer(Modifier.height(8.dp))
            Text(state.connection.error ?: "Rejected", color = HarshDanger, fontSize = 12.sp)
        }
    }
}
