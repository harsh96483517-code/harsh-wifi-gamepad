package com.harsh.wifigamepad.controller.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning
import com.harsh.wifigamepad.controller.network.ConnectionState
import com.harsh.wifigamepad.controller.network.DiscoveredTv
import com.harsh.wifigamepad.controller.ui.components.AccentPillButton
import com.harsh.wifigamepad.controller.ui.components.GlassChip
import com.harsh.wifigamepad.controller.ui.components.GlassPanel
import com.harsh.wifigamepad.controller.ui.components.PillShape
import com.harsh.wifigamepad.controller.ui.components.StatusPill
import com.harsh.wifigamepad.controller.ui.theme.HarshDanger
import com.harsh.wifigamepad.controller.ui.theme.HarshMuted
import com.harsh.wifigamepad.controller.ui.theme.LocalAccent
import com.harsh.wifigamepad.controller.viewmodel.ControllerUiState
import com.harsh.wifigamepad.protocol.QrPairingPayload

@Composable
fun PairingScreen(
    state: ControllerUiState,
    onStartDiscovery: () -> Unit,
    onConnect: (DiscoveredTv, pin: String) -> Unit,
    onConnectManual: (ip: String, port: Int, pin: String) -> Unit
) {
    val accent = LocalAccent.current
    val context = LocalContext.current
    var pin by remember { mutableStateOf("") }
    var manualIp by remember { mutableStateOf("") }
    var manualPort by remember { mutableStateOf("47821") }
    var showManual by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) { onStartDiscovery() }

    val fieldColors = OutlinedTextFieldDefaults.colors(
        focusedBorderColor = accent,
        unfocusedBorderColor = Color(0x55FFFFFF),
        focusedTextColor = Color.White,
        unfocusedTextColor = Color.White,
        focusedLabelColor = accent,
        unfocusedLabelColor = HarshMuted,
        cursorColor = accent
    )

    Column(
        Modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp, vertical = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("HARSH", color = accent, fontWeight = FontWeight.Black, fontSize = 34.sp)
        Text("WiFi GAMEPAD", color = Color(0xFFCFCFE0), fontWeight = FontWeight.Bold, fontSize = 13.sp, letterSpacing = 4.sp)
        Spacer(Modifier.height(16.dp))
        StatusPill(connected = state.connection.state == ConnectionState.CONNECTED, text = state.connectionLabel())
        Spacer(Modifier.height(20.dp))

        AccentPillButton(
            text = "SCAN TV QR CODE",
            onClick = {
                val options = GmsBarcodeScannerOptions.Builder()
                    .setBarcodeFormats(Barcode.FORMAT_QR_CODE)
                    .build()
                GmsBarcodeScanning.getClient(context, options).startScan()
                    .addOnSuccessListener { barcode ->
                        val payload = barcode.rawValue?.let { QrPairingPayload.decode(it) }
                        if (payload != null) {
                            message = null
                            onConnectManual(payload.ip, payload.port, payload.pin)
                        } else {
                            message = "This is not a HARSH TV QR code."
                        }
                    }
                    .addOnFailureListener { message = "Could not scan: ${it.message}" }
            },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(16.dp))
        Text("or pair with the PIN shown on your TV", color = HarshMuted, fontSize = 12.sp)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = pin,
            onValueChange = { if (it.length <= 6) pin = it.filter { c -> c.isDigit() } },
            label = { Text("Pairing PIN") },
            singleLine = true,
            shape = PillShape,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            colors = fieldColors,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(18.dp))
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("TVs ON YOUR NETWORK", color = HarshMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            GlassChip("SEARCH AGAIN", onStartDiscovery)
        }
        Spacer(Modifier.height(6.dp))

        LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
            if (state.discovered.isEmpty()) {
                item {
                    Text(
                        "No TV found yet. Open HARSH TV Receiver and make sure both devices use the same Wi-Fi.",
                        color = HarshMuted,
                        fontSize = 13.sp,
                        modifier = Modifier.padding(vertical = 12.dp)
                    )
                }
            }
            items(state.discovered) { tv ->
                GlassPanel(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                    shape = RoundedCornerShape(28.dp)
                ) {
                    Row(
                        Modifier.fillMaxWidth().padding(start = 20.dp, end = 12.dp, top = 12.dp, bottom = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(tv.name.ifBlank { "HARSH TV RECEIVER" }, color = Color.White, fontWeight = FontWeight.Bold)
                            Text("${tv.ip}:${tv.port}", color = HarshMuted, fontSize = 12.sp)
                        }
                        AccentPillButton(
                            text = "CONNECT",
                            height = 42.dp,
                            onClick = {
                                if (pin.length in 4..6) {
                                    message = null
                                    onConnect(tv, pin)
                                } else {
                                    message = "Enter the PIN shown on your TV first."
                                }
                            }
                        )
                    }
                }
            }
        }

        val err = message ?: if (state.connection.state == ConnectionState.REJECTED) (state.connection.error ?: "Rejected") else null
        err?.let {
            Text(it, color = HarshDanger, fontSize = 12.sp, modifier = Modifier.padding(vertical = 6.dp))
        }

        Text(
            if (showManual) "Hide manual entry" else "Enter IP manually",
            color = accent,
            fontWeight = FontWeight.Bold,
            fontSize = 13.sp,
            modifier = Modifier
                .clickable { showManual = !showManual }
                .padding(vertical = 10.dp)
        )
        if (showManual) {
            GlassPanel(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(28.dp)) {
                Column(Modifier.padding(16.dp)) {
                    OutlinedTextField(
                        value = manualIp,
                        onValueChange = { manualIp = it },
                        label = { Text("TV IP address") },
                        singleLine = true,
                        shape = PillShape,
                        colors = fieldColors,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = manualPort,
                        onValueChange = { manualPort = it.filter { c -> c.isDigit() } },
                        label = { Text("Port") },
                        singleLine = true,
                        shape = PillShape,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        colors = fieldColors,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(12.dp))
                    AccentPillButton(
                        text = "CONNECT",
                        modifier = Modifier.fillMaxWidth(),
                        onClick = {
                            val port = manualPort.toIntOrNull() ?: 47821
                            if (manualIp.isBlank()) {
                                message = "Enter the TV IP address."
                            } else if (pin.length !in 4..6) {
                                message = "Enter the PIN shown on your TV first."
                            } else {
                                message = null
                                onConnectManual(manualIp.trim(), port, pin)
                            }
                        }
                    )
                }
            }
        }
    }
}
