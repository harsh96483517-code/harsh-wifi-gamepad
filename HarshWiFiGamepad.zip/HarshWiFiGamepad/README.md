# HARSH WiFi GAMEPAD

Turn an Android phone into a game controller for an Android TV / Google TV device —
**entirely over the local Wi-Fi network. No Bluetooth. No cloud. No internet required
after installation.**

```
Phone 📱  →  Same Wi-Fi / Phone Hotspot  →  Android TV 📺
```

## Project layout (3 Gradle modules)

```
HarshWiFiGamepad/
├── protocol/      Pure-Kotlin shared library: wire protocol, message encode/decode
├── controller/    Phone app — the gamepad UI (Jetpack Compose)
├── tvreceiver/    TV app — the Wi-Fi receiver server (Jetpack Compose, Leanback banner)
├── build.gradle.kts, settings.gradle.kts, gradle.properties
└── gradlew / gradlew.bat
```

Both apps depend on `:protocol` so they always agree on the wire format.

## Features implemented (MVP + most advanced items)

**Controller (phone)**
- D-pad, left + right analog joysticks, A/B/X/Y, L1/L2/R1/R2, START/SELECT/HOME/BACK
- Button press animations, vibration feedback (toggleable)
- Landscape and portrait layouts
- Settings: controller name, button size, joystick sensitivity, vibration on/off,
  auto-reconnect, accent color, about
- Auto-discovery of TVs on the LAN + manual IP/port entry, PIN pairing
- Auto-reconnect with exponential backoff if the connection drops

**TV Receiver**
- Starts a local UDP server, shows IP / port / pairing PIN on screen
- Generates a QR code (offline, via ZXing) encoding IP+port+PIN for fast pairing
- Accepts phone connections automatically (LAN broadcast discovery) or via manual IP
- Shows "Connected: <name>", per-controller status, and disconnect-a-device action
- Rejects controllers with the wrong PIN; supports up to 4 simultaneous controllers
  (protocol has player "slots" built in)
- Detects dropped connections (missed heartbeats) and auto-recovers when the phone
  reconnects
- Closes its sockets safely on `onDestroy`

**Not built out further in this MVP** (noted as future work, architecture supports it):
- Controller layout *editor* (drag-to-reposition buttons) — button size/sensitivity
  sliders exist; a full drag-and-drop editor is a natural follow-up
- Full "themes" beyond the 3 accent swatches

## PPSSPP / third-party game support — what's possible and what's now implemented

This was explicitly checked and the gap has been closed as far as Android's
platform rules allow. Short version: **there is no root-free way for any
third-party Android app (ours included) to inject input into another
app it doesn't control, like PPSSPP.** That's not a bug in this project —
`android.permission.INJECT_EVENTS` is a signature/system-only permission no
sideloaded APK can hold, and the newer "virtual device" APIs require a
system-granted role most sideloaded apps and TV boxes don't have. Anyone
telling you a plain APK can force key presses into an arbitrary app without
root is describing something Android does not allow.

Given that, this receiver implements **three layers**, and is honest in the
UI about which one is active:

1. **Direct API** (`ControllerInputBus` / `ControllerInputListener`,
   `tvreceiver/.../api/`) — zero permissions, always on. Any game built to
   integrate with this receiver gets every raw button/joystick event
   directly. This does **not** help with PPSSPP specifically, since we can't
   modify PPSSPP's own source — it's the right answer for a *custom* game.
2. **Standard Android TV remote keys** (`AndroidKeyTranslator`) — D-pad,
   Back, Home, and Select/A are turned into the exact `KeyEvent`s a physical
   remote sends, so they work anywhere a remote's D-pad would. Doesn't cover
   X/Y/L1/L2/R1/R2/joysticks, and PPSSPP still won't see it as a "gamepad."
3. **NEW — root-only virtual gamepad** (`RootInputInjector`) — on a rooted
   TV, this uses Android's own `uinput` command (the same tool AOSP's CTS
   tests use; not an exploit) to register a real Linux joystick device with
   full analog X/Y/RX/RY axes, a D-pad hat, and all face/shoulder/start/select
   buttons. Once registered, **PPSSPP auto-detects it exactly like a real
   USB/Bluetooth gamepad** — no PPSSPP-side configuration needed, full analog
   stick control included. This is the piece that was missing and is now
   implemented in `tvreceiver/.../network/RootInputInjector.kt`, wired
   automatically into `GamepadServer.start()`/`stop()`.

The TV screen shows a live "PPSSPP / full game control" row: **Active
(rooted)** or **Unavailable (device not rooted)**. If your Android TV box
isn't rooted, PPSSPP will only receive Back/Home-style navigation via layer
2 — real gameplay buttons need layer 3, which needs root. This is disclosed
rather than hidden because it's a genuine platform limitation, not something
more code can work around.

If you don't want to root the TV: pairing a Bluetooth gamepad directly with
PPSSPP (bypassing this whole project) is the zero-effort alternative PPSSPP
already supports natively — but that reintroduces Bluetooth, which this
project was specifically built to avoid.

## The protocol (UDP, `:protocol` module)

Chosen transport: **UDP**, because dropped/late packets matter more for a game
controller than occasional loss — TCP's retransmission would add latency spikes.
Reliability where it matters (pairing, disconnect) is handled with short retry loops.

```
Discovery (broadcast, port 47822):
  HARSH_DISCOVER|<version>                          phone -> broadcast
  HARSH_HERE|<tvName>|<gamePort>|<version>           TV -> phone (unicast reply)

Pairing / session (unicast, port 47821 by default):
  HELLO|<controllerId>|<controllerName>|<pin>|<version>   phone -> TV
  WELCOME|<sessionToken>|<slot>                            TV -> phone (accepted)
  REJECT|<reason>                                          TV -> phone (bad PIN / full)

Liveness:
  PING|<clientTimeMillis>                                  phone -> TV
  PONG|<clientTimeMillis>|<serverTimeMillis>               TV -> phone

Gameplay input (wrapped with session token + sequence number):
  INPUT|<sessionToken>|<seq>|BUTTON_DOWN:<code>
  INPUT|<sessionToken>|<seq>|BUTTON_UP:<code>
  INPUT|<sessionToken>|<seq>|JOYSTICK_LEFT:<x>,<y>
  INPUT|<sessionToken>|<seq>|JOYSTICK_RIGHT:<x>,<y>

Disconnect:
  BYE|<sessionToken>                                       phone -> TV
```

`<code>` is one of: `A B X Y L1 L2 R1 R2 START SELECT HOME BACK DPAD_UP DPAD_DOWN
DPAD_LEFT DPAD_RIGHT`. `slot` (0–3) is reserved for multi-controller support — the
server already tracks up to `ProtocolConstants.MAX_CONTROLLERS` (4) concurrent
sessions, each with its own slot, so a couch-co-op mode just needs a second phone.

QR pairing payload: `HARSHPAIR|<ip>|<port>|<pin>|<tvName>`.

## Security

- Every session requires a **PIN** (randomly regenerated each time the TV app starts)
  shown on the TV screen / embedded in the QR code — the phone must know it to pair.
- Unknown/unpinned controllers are rejected (`REJECT|Incorrect PIN`).
- The TV screen lists connected controllers and lets you **disconnect** any of them.
- No traffic ever leaves the local network; there is no server component and no
  telemetry. `usesCleartextTraffic="true"` is only relevant because this is a raw UDP
  socket app on the LAN, not an HTTPS client — nothing is sent to the internet.
- Sockets are closed in `stop()` / `onDestroy()` on both ends.
- The root-only virtual-gamepad path (`RootInputInjector`) only ever calls `su` to run
  Android's own signed `uinput` binary with a fixed, hardcoded device descriptor — it
  never runs commands built from network input, so a malicious phone on the same
  Wi-Fi can send button/joystick events but cannot use this path to run arbitrary
  shell commands on the TV.

## Build & install

### About this delivery — what's compiled here vs. what you run locally
This project was assembled in a network-isolated build sandbox with no Android SDK
and no internet access, so **it could not run an actual Gradle build here** — it
can't download the Android SDK platform/build-tools, the Gradle 8.7 distribution, or
the Kotlin/Compose/AndroidX/ZXing libraries the project depends on, and it can't
fetch the real `gradle-wrapper.jar` binary either (that file has to come from
Gradle's own servers). Every `.kt`/`.xml`/`.gradle.kts` file has been hand-verified
(package/path consistency, dependency wiring, protocol-to-implementation consistency
— see the review notes in this repo's commit history if you use one), but the two
debug APKs and `gradle-wrapper.jar` themselves have to be produced by a real build,
on a machine with internet access. The commands below are exact and copy-pasteable —
this is a one-time, ~2 minute step.

### 0. One-time: generate the Gradle wrapper jar
On a machine with internet access and a JDK 17+ installed:
```bash
cd HarshWiFiGamepad
gradle wrapper --gradle-version 8.7 --distribution-type bin
```
(If you don't have standalone `gradle` installed, opening the project in **Android
Studio Iguana (2023.2.1) or newer** does this automatically on first sync — skip
straight to step 2 in that case.) This populates `gradle/wrapper/gradle-wrapper.jar`;
`gradle/wrapper/gradle-wrapper.properties` here is already pinned to Gradle 8.7, so
no further configuration is needed.

### 1. Command-line build (fastest way to get both APKs)
```bash
cd HarshWiFiGamepad
./gradlew :controller:assembleDebug :tvreceiver:assembleDebug
```
First run downloads Gradle 8.7 + the Android SDK components + all dependencies
(needs internet + `ANDROID_HOME`/`ANDROID_SDK_ROOT` set, or let Android Studio
manage the SDK and run this from its embedded terminal). Output:
```
controller/build/outputs/apk/debug/controller-debug.apk
tvreceiver/build/outputs/apk/debug/tvreceiver-debug.apk
```

### 2. Or open in Android Studio
1. `File → Open` → select the `HarshWiFiGamepad/` folder, let Gradle sync.
2. Two run configurations appear: **controller** and **tvreceiver**.
3. `Build → Build Bundle(s)/APK(s) → Build APK(s)` for each module, or just click
   **Run** with the right device selected (see below).

### 3. Install the Controller APK on your phone
```bash
adb install -r controller/build/outputs/apk/debug/controller-debug.apk
```
(Enable Developer Options → USB debugging on the phone first, connect via USB, or
run this from Android Studio's Run button with the phone selected as target.)

### 4. Install the TV Receiver APK on your Android TV / Google TV
```bash
adb connect <tv-ip>:5555        # enable Developer options -> Network/USB debugging on the TV first
adb -s <tv-ip>:5555 install -r tvreceiver/build/outputs/apk/debug/tvreceiver-debug.apk
```
If your TV box doesn't support ADB, sideload `tvreceiver-debug.apk` via a USB drive
and a file manager app instead.

### 5. Connect the two
1. Make sure the phone and the TV are on the **same Wi-Fi network** (or the phone is
   the TV's connected hotspot).
2. Launch **HARSH TV Receiver** on the TV — it shows its IP, port, PIN, and a QR code.
3. Launch **HARSH WiFi GAMEPAD** on the phone — it searches for TVs automatically.
   Enter the PIN shown on the TV, tap the discovered "HARSH TV RECEIVER" entry (or
   use "Enter IP manually" if discovery doesn't find it, e.g. across some routers
   that block broadcast/multicast).
4. Once connected, the TV shows "Connected: HARSH PHONE" and the phone switches to
   the full gamepad UI.

## Extending it

- **New buttons or axes**: add to `ButtonCode` in `protocol/.../GamepadEvent.kt` —
  both apps pick it up immediately since they share the module.
- **A real game using this as input**: implement `ControllerInputListener`, call
  `ControllerInputBus.register(...)`, and you get every event live. No networking
  code needed in the game itself.
- **More controllers**: already supported up to `ProtocolConstants.MAX_CONTROLLERS`;
  raise that constant and the TV UI's controller list will show all of them.

## Quick build (one command)
```bash
./build-apks.sh
```
Produces `dist/controller-debug.apk` (phone) and `dist/tvreceiver-debug.apk` (TV).
