package com.harsh.wifigamepad.protocol

/**
 * HARSH WiFi GAMEPAD wire protocol.
 *
 * Transport: UDP (chosen over TCP for low-latency input; occasional dropped
 * button/joystick packets are acceptable and are self-correcting because the
 * controller repeats joystick state at [ProtocolConstants.JOYSTICK_RESEND_HZ]
 * and button-up events are sent reliably-ish via a small resend window).
 *
 * Every packet is a single line of ASCII text terminated conceptually by the
 * UDP datagram boundary (no trailing newline needed, but one is tolerated).
 *
 * Message families:
 *
 *  HELLO|<controllerId>|<controllerName>|<pin>|<protocolVersion>
 *      Sent by phone -> TV to begin pairing / reconnect.
 *
 *  WELCOME|<sessionToken>|<slot>
 *      Sent by TV -> phone once HELLO is accepted. `slot` is the player
 *      index (0-based) reserved for multi-controller support.
 *
 *  REJECT|<reason>
 *      Sent by TV -> phone if PIN is wrong or no slots are free.
 *
 *  PING|<clientTimeMillis>
 *  PONG|<clientTimeMillis>|<serverTimeMillis>
 *      Latency measurement, sent periodically by the phone once connected.
 *
 *  INPUT|<sessionToken>|<seq>|<event>
 *      Wraps every gamepad event below with the session token (so the TV can
 *      reject spoofed/unknown controllers) and a monotonically increasing
 *      sequence number (so out-of-order UDP packets can be discarded).
 *
 *  BYE|<sessionToken>
 *      Sent by phone -> TV on clean disconnect.
 *
 * Gamepad events (the payload carried inside INPUT|...|...|<event>):
 *
 *  BUTTON_DOWN:<code>
 *  BUTTON_UP:<code>
 *  JOYSTICK_LEFT:<x>,<y>
 *  JOYSTICK_RIGHT:<x>,<y>
 *
 * Discovery (separate broadcast channel, see DiscoveryMessage.kt):
 *
 *  HARSH_DISCOVER|<protocolVersion>
 *  HARSH_HERE|<tvName>|<tcpPort-unused>|<udpPort>|<protocolVersion>
 */
object ProtocolConstants {
    const val PROTOCOL_VERSION = 1
    const val DEFAULT_GAME_PORT = 47821
    const val DISCOVERY_PORT = 47822
    const val DISCOVERY_REQUEST = "HARSH_DISCOVER"
    const val DISCOVERY_RESPONSE = "HARSH_HERE"
    const val JOYSTICK_RESEND_HZ = 30
    const val MAX_CONTROLLERS = 4
    const val FIELD_SEPARATOR = "|"
}

enum class ButtonCode {
    A, B, X, Y,
    L1, L2, R1, R2,
    START, SELECT, HOME, BACK,
    DPAD_UP, DPAD_DOWN, DPAD_LEFT, DPAD_RIGHT
}

sealed class GamepadEvent {
    data class ButtonDown(val code: ButtonCode) : GamepadEvent()
    data class ButtonUp(val code: ButtonCode) : GamepadEvent()
    data class JoystickLeft(val x: Float, val y: Float) : GamepadEvent()
    data class JoystickRight(val x: Float, val y: Float) : GamepadEvent()

    fun encode(): String = when (this) {
        is ButtonDown -> "BUTTON_DOWN:${code.name}"
        is ButtonUp -> "BUTTON_UP:${code.name}"
        is JoystickLeft -> "JOYSTICK_LEFT:${fmt(x)},${fmt(y)}"
        is JoystickRight -> "JOYSTICK_RIGHT:${fmt(x)},${fmt(y)}"
    }

    companion object {
        private fun fmt(v: Float): String = "%.2f".format(v).trimEnd('0').trimEnd('.').ifEmpty { "0" }

        fun decode(raw: String): GamepadEvent? {
            val idx = raw.indexOf(':')
            if (idx == -1) return null
            val type = raw.substring(0, idx)
            val body = raw.substring(idx + 1)
            return try {
                when (type) {
                    "BUTTON_DOWN" -> ButtonDown(ButtonCode.valueOf(body))
                    "BUTTON_UP" -> ButtonUp(ButtonCode.valueOf(body))
                    "JOYSTICK_LEFT" -> body.split(",").let { JoystickLeft(it[0].toFloat(), it[1].toFloat()) }
                    "JOYSTICK_RIGHT" -> body.split(",").let { JoystickRight(it[0].toFloat(), it[1].toFloat()) }
                    else -> null
                }
            } catch (e: Exception) {
                null
            }
        }
    }
}

/** Wraps a GamepadEvent with routing/session info for the INPUT|... frame. */
data class InputFrame(
    val sessionToken: String,
    val seq: Long,
    val event: GamepadEvent
) {
    fun encode(): String =
        listOf("INPUT", sessionToken, seq.toString(), event.encode()).joinToString(ProtocolConstants.FIELD_SEPARATOR)

    companion object {
        fun decode(raw: String): InputFrame? {
            val parts = raw.split(ProtocolConstants.FIELD_SEPARATOR, limit = 4)
            if (parts.size != 4 || parts[0] != "INPUT") return null
            val seq = parts[2].toLongOrNull() ?: return null
            val event = GamepadEvent.decode(parts[3]) ?: return null
            return InputFrame(parts[1], seq, event)
        }
    }
}

data class HelloFrame(
    val controllerId: String,
    val controllerName: String,
    val pin: String,
    val protocolVersion: Int = ProtocolConstants.PROTOCOL_VERSION
) {
    fun encode(): String =
        listOf("HELLO", controllerId, controllerName, pin, protocolVersion.toString())
            .joinToString(ProtocolConstants.FIELD_SEPARATOR)

    companion object {
        fun decode(raw: String): HelloFrame? {
            val parts = raw.split(ProtocolConstants.FIELD_SEPARATOR)
            if (parts.size != 5 || parts[0] != "HELLO") return null
            val version = parts[4].toIntOrNull() ?: return null
            return HelloFrame(parts[1], parts[2], parts[3], version)
        }
    }
}

data class WelcomeFrame(val sessionToken: String, val slot: Int) {
    fun encode(): String = listOf("WELCOME", sessionToken, slot.toString()).joinToString(ProtocolConstants.FIELD_SEPARATOR)

    companion object {
        fun decode(raw: String): WelcomeFrame? {
            val parts = raw.split(ProtocolConstants.FIELD_SEPARATOR)
            if (parts.size != 3 || parts[0] != "WELCOME") return null
            val slot = parts[2].toIntOrNull() ?: return null
            return WelcomeFrame(parts[1], slot)
        }
    }
}

data class RejectFrame(val reason: String) {
    fun encode(): String = "REJECT${ProtocolConstants.FIELD_SEPARATOR}$reason"
    companion object {
        fun decode(raw: String): RejectFrame? {
            val parts = raw.split(ProtocolConstants.FIELD_SEPARATOR, limit = 2)
            if (parts.size != 2 || parts[0] != "REJECT") return null
            return RejectFrame(parts[1])
        }
    }
}

data class PingFrame(val clientTimeMillis: Long) {
    fun encode(): String = "PING${ProtocolConstants.FIELD_SEPARATOR}$clientTimeMillis"
    companion object {
        fun decode(raw: String): PingFrame? {
            val parts = raw.split(ProtocolConstants.FIELD_SEPARATOR)
            if (parts.size != 2 || parts[0] != "PING") return null
            return PingFrame(parts[1].toLongOrNull() ?: return null)
        }
    }
}

data class PongFrame(val clientTimeMillis: Long, val serverTimeMillis: Long) {
    fun encode(): String = listOf("PONG", clientTimeMillis, serverTimeMillis).joinToString(ProtocolConstants.FIELD_SEPARATOR)
    companion object {
        fun decode(raw: String): PongFrame? {
            val parts = raw.split(ProtocolConstants.FIELD_SEPARATOR)
            if (parts.size != 3 || parts[0] != "PONG") return null
            val c = parts[1].toLongOrNull() ?: return null
            val s = parts[2].toLongOrNull() ?: return null
            return PongFrame(c, s)
        }
    }
}

data class ByeFrame(val sessionToken: String) {
    fun encode(): String = "BYE${ProtocolConstants.FIELD_SEPARATOR}$sessionToken"
    companion object {
        fun decode(raw: String): ByeFrame? {
            val parts = raw.split(ProtocolConstants.FIELD_SEPARATOR)
            if (parts.size != 2 || parts[0] != "BYE") return null
            return ByeFrame(parts[1])
        }
    }
}
