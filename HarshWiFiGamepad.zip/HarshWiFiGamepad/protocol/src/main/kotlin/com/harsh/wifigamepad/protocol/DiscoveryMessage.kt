package com.harsh.wifigamepad.protocol

/**
 * Broadcast/multicast discovery so the phone can find "HARSH TV RECEIVER"
 * automatically without the user typing an IP address.
 *
 * Flow:
 *  1. Phone broadcasts DISCOVER_REQUEST on [ProtocolConstants.DISCOVERY_PORT] (UDP broadcast, 255.255.255.255).
 *  2. Every TV receiver listening on that port replies directly (unicast) to
 *     the sender with a DISCOVER_RESPONSE containing its name, IP (implicit
 *     from the packet source address) and game port.
 *  3. Phone lists all TVs that responded within a short window.
 */
data class DiscoveryRequest(val protocolVersion: Int = ProtocolConstants.PROTOCOL_VERSION) {
    fun encode(): String = "${ProtocolConstants.DISCOVERY_REQUEST}${ProtocolConstants.FIELD_SEPARATOR}$protocolVersion"

    companion object {
        fun decode(raw: String): DiscoveryRequest? {
            val parts = raw.split(ProtocolConstants.FIELD_SEPARATOR)
            if (parts.size != 2 || parts[0] != ProtocolConstants.DISCOVERY_REQUEST) return null
            val v = parts[1].toIntOrNull() ?: return null
            return DiscoveryRequest(v)
        }
    }
}

data class DiscoveryResponse(
    val tvName: String,
    val gamePort: Int,
    val protocolVersion: Int = ProtocolConstants.PROTOCOL_VERSION
) {
    fun encode(): String =
        listOf(ProtocolConstants.DISCOVERY_RESPONSE, tvName, gamePort, protocolVersion)
            .joinToString(ProtocolConstants.FIELD_SEPARATOR)

    companion object {
        fun decode(raw: String): DiscoveryResponse? {
            val parts = raw.split(ProtocolConstants.FIELD_SEPARATOR)
            if (parts.size != 4 || parts[0] != ProtocolConstants.DISCOVERY_RESPONSE) return null
            val port = parts[2].toIntOrNull() ?: return null
            val version = parts[3].toIntOrNull() ?: return null
            return DiscoveryResponse(parts[1], port, version)
        }
    }
}

/** Payload encoded into the QR code shown on the TV pairing screen. */
data class QrPairingPayload(
    val ip: String,
    val port: Int,
    val pin: String,
    val tvName: String
) {
    fun encode(): String =
        listOf("HARSHPAIR", ip, port, pin, tvName).joinToString(ProtocolConstants.FIELD_SEPARATOR)

    companion object {
        fun decode(raw: String): QrPairingPayload? {
            val parts = raw.split(ProtocolConstants.FIELD_SEPARATOR)
            if (parts.size != 5 || parts[0] != "HARSHPAIR") return null
            val port = parts[2].toIntOrNull() ?: return null
            return QrPairingPayload(parts[1], port, parts[3], parts[4])
        }
    }
}
